import { useState, useEffect, useRef, useCallback } from "react";
import { Navbar } from "./components/Navbar";
import { CandleChart } from "./components/CandleChart";
import { TradingPanel } from "./components/TradingPanel";
import { AssetSelector, type Asset } from "./components/AssetSelector";
import { TradeHistory, type TradeRecord } from "./components/TradeHistory";
import { StatsBar } from "./components/StatsBar";
import { DepositModal } from "./components/DepositModal";
import { AdminDashboard } from "./components/admin/AdminDashboard";
import { UserDashboard } from "./components/user/UserDashboard";

interface Candle {
  open: number;
  close: number;
  high: number;
  low: number;
  time: number;
}

const INITIAL_ASSETS: Asset[] = [
  { id: "btcusd", name: "Bitcoin / USD", symbol: "BTC/USD", price: 67432.50, change: 2.34, icon: "₿", payout: 85 },
  { id: "ethusd", name: "Ethereum / USD", symbol: "ETH/USD", price: 3821.75, change: -1.12, icon: "Ξ", payout: 82 },
  { id: "eurusd", name: "Euro / US Dollar", symbol: "EUR/USD", price: 1.0872, change: 0.18, icon: "€", payout: 80 },
  { id: "gbpusd", name: "British Pound / USD", symbol: "GBP/USD", price: 1.2645, change: -0.43, icon: "£", payout: 80 },
  { id: "gold",   name: "Gold / USD", symbol: "XAU/USD", price: 2318.40, change: 0.92, icon: "🥇", payout: 78 },
  { id: "sp500",  name: "S&P 500 Index", symbol: "SPX500", price: 5248.90, change: 1.05, icon: "📈", payout: 75 },
];

function generateInitialCandles(basePrice: number, count = 80): Candle[] {
  const candles: Candle[] = [];
  let price = basePrice;
  const now = Date.now();
  for (let i = count; i >= 0; i--) {
    const volatility = basePrice * 0.0018;
    const move = (Math.random() - 0.48) * volatility;
    const open = price;
    const close = open + move;
    const high = Math.max(open, close) + Math.random() * volatility * 0.6;
    const low = Math.min(open, close) - Math.random() * volatility * 0.6;
    candles.push({ open, close, high, low, time: now - i * 5000 });
    price = close;
  }
  return candles;
}

export function App() {
  const [showAdmin, setShowAdmin] = useState(false);
  const [showUserDashboard, setShowUserDashboard] = useState(false);
  const [assets, setAssets] = useState<Asset[]>(INITIAL_ASSETS);
  const [selectedAssetId, setSelectedAssetId] = useState("btcusd");
  const [candles, setCandles] = useState<Record<string, Candle[]>>(() => {
    const map: Record<string, Candle[]> = {};
    INITIAL_ASSETS.forEach(a => { map[a.id] = generateInitialCandles(a.price); });
    return map;
  });
  const [balance, setBalance] = useState(1000);
  const [isTrading, setIsTrading] = useState(false);
  const [tradeDirection, setTradeDirection] = useState<"up" | "down" | null>(null);
  const [tradeDuration, setTradeDuration] = useState(60);
  const [timeLeft, setTimeLeft] = useState(0);
  const [entryPrice, setEntryPrice] = useState<number | null>(null);
  const [tradeAmount, setTradeAmount] = useState(0);
  const [trades, setTrades] = useState<TradeRecord[]>([]);
  const [lastResult, setLastResult] = useState<{ won: boolean; profit: number } | null>(null);
  const [showDeposit, setShowDeposit] = useState(false);
  const [volume, setVolume] = useState("2.4B");

  const tickerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const tradeTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const selectedAsset = assets.find(a => a.id === selectedAssetId)!;
  const currentCandles = candles[selectedAssetId] || [];
  const currentPrice = currentCandles[currentCandles.length - 1]?.close ?? selectedAsset.price;

  // Price tick
  const tick = useCallback(() => {
    setAssets(prev => prev.map(asset => {
      const volatility = asset.price * 0.0012;
      const delta = (Math.random() - 0.49) * volatility;
      const newPrice = parseFloat((asset.price + delta).toFixed(asset.id.includes("usd") && !asset.id.startsWith("btc") && !asset.id.startsWith("eth") ? 4 : 2));
      const changePct = ((newPrice - INITIAL_ASSETS.find(a => a.id === asset.id)!.price) / INITIAL_ASSETS.find(a => a.id === asset.id)!.price) * 100;
      return { ...asset, price: newPrice, change: parseFloat(changePct.toFixed(2)) };
    }));

    setCandles(prev => {
      const next = { ...prev };
      Object.keys(next).forEach(id => {
        const asset = INITIAL_ASSETS.find(a => a.id === id)!;
        const existingCandles = next[id];
        const last = existingCandles[existingCandles.length - 1];
        const now = Date.now();
        const volatility = last.close * 0.0012;
        const move = (Math.random() - 0.49) * volatility;
        const newClose = last.close + move;

        const CANDLE_DURATION = 5000;
        if (now - last.time >= CANDLE_DURATION) {
          // New candle
          next[id] = [...existingCandles.slice(-99), {
            open: last.close,
            close: newClose,
            high: Math.max(last.close, newClose) + Math.random() * volatility * 0.4,
            low: Math.min(last.close, newClose) - Math.random() * volatility * 0.4,
            time: now,
          }];
        } else {
          // Update current candle
          const updated = { ...last, close: newClose, high: Math.max(last.high, newClose), low: Math.min(last.low, newClose) };
          next[id] = [...existingCandles.slice(0, -1), updated];
        }
        void asset;
      });
      return next;
    });

    setVolume(`${(Math.random() * 3 + 1).toFixed(1)}B`);
  }, []);

  useEffect(() => {
    tickerRef.current = setInterval(tick, 800);
    return () => { if (tickerRef.current) clearInterval(tickerRef.current); };
  }, [tick]);

  // Trade timer
  useEffect(() => {
    if (isTrading && timeLeft > 0) {
      tradeTimerRef.current = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            clearInterval(tradeTimerRef.current!);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => { if (tradeTimerRef.current) clearInterval(tradeTimerRef.current); };
  }, [isTrading, timeLeft]);

  // Resolve trade when timeLeft hits 0
  useEffect(() => {
    if (isTrading && timeLeft === 0 && entryPrice !== null) {
      const exitPrice = currentPrice;
      const won =
        tradeDirection === "up" ? exitPrice > entryPrice : exitPrice < entryPrice;
      const payout = selectedAsset.payout;
      const profit = parseFloat((tradeAmount * (payout / 100)).toFixed(2));

      setBalance(prev => won ? prev + profit : prev - tradeAmount);

      const result = { won, profit: won ? profit : tradeAmount };
      setLastResult(result);

      const newTrade: TradeRecord = {
        id: Date.now().toString(),
        asset: selectedAsset.symbol,
        direction: tradeDirection!,
        amount: tradeAmount,
        profit,
        won,
        entryPrice,
        exitPrice,
        time: new Date().toLocaleTimeString(),
      };
      setTrades(prev => [...prev, newTrade]);

      setIsTrading(false);
      setTradeDirection(null);
      setEntryPrice(null);
    }
  }, [timeLeft, isTrading, entryPrice, currentPrice, tradeDirection, tradeAmount, selectedAsset]);

  const handleTrade = (direction: "up" | "down", amount: number, duration: number) => {
    if (amount > balance) return;
    setTradeDirection(direction);
    setTradeDuration(duration);
    setTimeLeft(duration);
    setEntryPrice(currentPrice);
    setTradeAmount(amount);
    setIsTrading(true);
    setLastResult(null);
  };

  const handleDeposit = (amount: number) => {
    setBalance(prev => prev + amount);
  };

  // Compute stats
  const allCloses = currentCandles.map(c => c.close);
  const high24 = currentCandles.length ? Math.max(...currentCandles.map(c => c.high)) : currentPrice;
  const low24 = currentCandles.length ? Math.min(...currentCandles.map(c => c.low)) : currentPrice;
  const open24 = currentCandles[0]?.open ?? currentPrice;
  void allCloses;

  const handleWithdraw = (amount: number) => {
    setBalance(prev => Math.max(0, prev - amount));
  };

  if (showAdmin) {
    return <AdminDashboard onExit={() => setShowAdmin(false)} />;
  }

  if (showUserDashboard) {
    return (
      <UserDashboard
        balance={balance}
        onDeposit={handleDeposit}
        onWithdraw={handleWithdraw}
        trades={trades}
        onClose={() => setShowUserDashboard(false)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      <Navbar balance={balance} onDeposit={() => setShowDeposit(true)} onAdmin={() => setShowAdmin(true)} onAccount={() => setShowUserDashboard(true)} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col gap-4">
        {/* Stats Bar */}
        <StatsBar
          currentPrice={currentPrice}
          open={open24}
          high={high24}
          low={low24}
          volume={volume}
          payout={selectedAsset.payout}
          assetName={selectedAsset.symbol}
        />

        {/* Main Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-[220px_1fr_280px] gap-4">
          {/* Asset List */}
          <div className="order-2 lg:order-1">
            <AssetSelector
              assets={assets}
              selectedId={selectedAssetId}
              onSelect={id => { setSelectedAssetId(id); setLastResult(null); setIsTrading(false); setTradeDirection(null); setEntryPrice(null); }}
            />
          </div>

          {/* Chart */}
          <div className="order-1 lg:order-2 bg-gray-900 border border-gray-800 rounded-2xl p-3 min-h-[380px] flex flex-col">
            <div className="flex items-center justify-between mb-2 px-1">
              <div className="flex items-center gap-2">
                <span className="text-white font-semibold text-sm">{selectedAsset.symbol}</span>
                <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${currentPrice >= open24 ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"}`}>
                  {currentPrice >= open24 ? "▲ BULLISH" : "▼ BEARISH"}
                </span>
              </div>
              <div className="flex items-center gap-1">
                {["1m", "5m", "15m", "1H"].map(tf => (
                  <button key={tf} className={`text-xs px-2 py-1 rounded-md ${tf === "5m" ? "bg-cyan-500/20 text-cyan-400" : "text-gray-500 hover:text-gray-300"}`}>{tf}</button>
                ))}
              </div>
            </div>
            <div className="flex-1">
              <CandleChart
                candles={currentCandles}
                currentPrice={currentPrice}
                direction={tradeDirection}
                timeLeft={timeLeft}
                totalTime={tradeDuration}
                entryPrice={entryPrice}
              />
            </div>
          </div>

          {/* Trading Panel */}
          <div className="order-3">
            <TradingPanel
              onTrade={handleTrade}
              isTrading={isTrading}
              direction={tradeDirection}
              timeLeft={timeLeft}
              balance={balance}
              lastResult={lastResult}
              payout={selectedAsset.payout}
            />
          </div>
        </div>

        {/* Trade History */}
        <TradeHistory trades={trades} />
      </div>

      {/* Deposit Modal */}
      {showDeposit && (
        <DepositModal onClose={() => setShowDeposit(false)} onDeposit={handleDeposit} />
      )}
    </div>
  );
}
