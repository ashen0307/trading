import { useState } from "react";

interface DepositModalProps {
  onClose: () => void;
  onDeposit: (amount: number) => void;
}

const AMOUNTS = [100, 250, 500, 1000, 2500, 5000];

export function DepositModal({ onClose, onDeposit }: DepositModalProps) {
  const [selected, setSelected] = useState(500);
  const [custom, setCustom] = useState("");
  const [step, setStep] = useState<"amount" | "success">("amount");

  const finalAmount = custom ? parseFloat(custom) : selected;

  const handleDeposit = () => {
    if (!finalAmount || finalAmount <= 0) return;
    onDeposit(finalAmount);
    setStep("success");
    setTimeout(() => {
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={onClose}>
      <div
        className="bg-gray-900 border border-gray-700 rounded-2xl w-full max-w-md shadow-2xl"
        onClick={e => e.stopPropagation()}
      >
        {step === "success" ? (
          <div className="p-8 text-center">
            <div className="w-16 h-16 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h3 className="text-white text-xl font-bold mb-2">Deposit Successful!</h3>
            <p className="text-emerald-400 font-semibold text-lg">${finalAmount.toLocaleString()} added to your account</p>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between p-5 border-b border-gray-800">
              <h2 className="text-white font-bold text-lg">Deposit Funds</h2>
              <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="p-5 flex flex-col gap-5">
              <div>
                <label className="text-gray-400 text-xs font-medium uppercase tracking-wider mb-3 block">Select Amount</label>
                <div className="grid grid-cols-3 gap-2">
                  {AMOUNTS.map(a => (
                    <button
                      key={a}
                      onClick={() => { setSelected(a); setCustom(""); }}
                      className={`py-2.5 rounded-xl text-sm font-semibold transition-all ${
                        selected === a && !custom
                          ? "bg-emerald-500 text-white shadow-lg shadow-emerald-500/25"
                          : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white"
                      }`}
                    >
                      ${a.toLocaleString()}
                    </button>
                  ))}
                </div>
              </div>

              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 font-semibold">$</span>
                <input
                  type="number"
                  value={custom}
                  onChange={e => setCustom(e.target.value)}
                  placeholder="Custom amount"
                  className="w-full bg-gray-800 border border-gray-700 focus:border-emerald-500 text-white rounded-xl pl-7 pr-4 py-3 text-sm outline-none transition-colors"
                />
              </div>

              <div className="bg-gray-800 rounded-xl p-4">
                <div className="text-gray-400 text-xs mb-3 font-medium uppercase tracking-wider">Payment Method</div>
                <div className="grid grid-cols-3 gap-2">
                  {["💳 Card", "🏦 Bank", "₿ Crypto"].map(m => (
                    <button key={m} className="bg-gray-700 hover:bg-gray-600 text-gray-300 text-xs font-medium py-2 rounded-lg transition-colors">
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={handleDeposit}
                className="w-full bg-emerald-500 hover:bg-emerald-400 text-white font-bold py-4 rounded-xl transition-all shadow-lg shadow-emerald-500/25 text-base"
              >
                Deposit ${finalAmount ? finalAmount.toLocaleString() : "0"}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
