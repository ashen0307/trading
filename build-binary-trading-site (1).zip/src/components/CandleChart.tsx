import { useEffect, useRef } from "react";

interface Candle {
  open: number;
  close: number;
  high: number;
  low: number;
  time: number;
}

interface CandleChartProps {
  candles: Candle[];
  currentPrice: number;
  direction: "up" | "down" | null;
  timeLeft: number;
  totalTime: number;
  entryPrice: number | null;
}

export function CandleChart({ candles, currentPrice, direction, timeLeft, totalTime, entryPrice }: CandleChartProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    const padding = { top: 20, bottom: 30, left: 10, right: 70 };
    const chartW = W - padding.left - padding.right;
    const chartH = H - padding.top - padding.bottom;

    const displayCandles = candles.slice(-60);
    if (displayCandles.length === 0) return;

    const prices = displayCandles.flatMap(c => [c.high, c.low]);
    const minP = Math.min(...prices) * 0.9995;
    const maxP = Math.max(...prices) * 1.0005;
    const priceRange = maxP - minP;

    const toY = (p: number) => padding.top + chartH - ((p - minP) / priceRange) * chartH;
    const candleW = Math.max(3, (chartW / displayCandles.length) * 0.6);
    const step = chartW / displayCandles.length;

    // Grid
    ctx.strokeStyle = "#1f2937";
    ctx.lineWidth = 1;
    for (let i = 0; i <= 5; i++) {
      const y = padding.top + (chartH / 5) * i;
      ctx.beginPath();
      ctx.moveTo(padding.left, y);
      ctx.lineTo(W - padding.right, y);
      ctx.stroke();
      const price = maxP - (priceRange / 5) * i;
      ctx.fillStyle = "#6b7280";
      ctx.font = "10px monospace";
      ctx.textAlign = "left";
      ctx.fillText(price.toFixed(2), W - padding.right + 4, y + 3);
    }

    // Entry price line
    if (entryPrice !== null) {
      const ey = toY(entryPrice);
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = "#f59e0b";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(padding.left, ey);
      ctx.lineTo(W - padding.right, ey);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.fillStyle = "#f59e0b";
      ctx.fillRect(W - padding.right + 2, ey - 8, 62, 16);
      ctx.fillStyle = "#000";
      ctx.font = "bold 10px monospace";
      ctx.textAlign = "center";
      ctx.fillText(entryPrice.toFixed(2), W - padding.right + 33, ey + 4);
    }

    // Candles
    displayCandles.forEach((c, i) => {
      const x = padding.left + i * step + step / 2;
      const isUp = c.close >= c.open;
      const color = isUp ? "#10b981" : "#ef4444";

      ctx.strokeStyle = color;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x, toY(c.high));
      ctx.lineTo(x, toY(c.low));
      ctx.stroke();

      ctx.fillStyle = color;
      const bodyTop = toY(Math.max(c.open, c.close));
      const bodyBot = toY(Math.min(c.open, c.close));
      const bodyH = Math.max(1, bodyBot - bodyTop);
      ctx.fillRect(x - candleW / 2, bodyTop, candleW, bodyH);
    });

    // Current price line
    const cy = toY(currentPrice);
    ctx.setLineDash([]);
    ctx.strokeStyle = "#60a5fa";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(padding.left, cy);
    ctx.lineTo(W - padding.right, cy);
    ctx.stroke();

    ctx.fillStyle = "#3b82f6";
    ctx.fillRect(W - padding.right + 2, cy - 9, 62, 18);
    ctx.fillStyle = "#fff";
    ctx.font = "bold 11px monospace";
    ctx.textAlign = "center";
    ctx.fillText(currentPrice.toFixed(2), W - padding.right + 33, cy + 4);

    // Timer bar at bottom
    if (direction !== null && totalTime > 0) {
      const progress = timeLeft / totalTime;
      const barH = 6;
      const barY = H - barH;
      ctx.fillStyle = "#1f2937";
      ctx.fillRect(0, barY, W, barH);
      const barColor = direction === "up" ? "#10b981" : "#ef4444";
      ctx.fillStyle = barColor;
      ctx.fillRect(0, barY, W * progress, barH);
    }

  }, [candles, currentPrice, direction, timeLeft, totalTime, entryPrice]);

  return (
    <canvas
      ref={canvasRef}
      width={900}
      height={380}
      className="w-full h-full rounded-xl"
      style={{ display: "block" }}
    />
  );
}
