import { useState } from "react";
import { cn } from "@/utils/cn";

interface NavbarProps {
  balance: number;
  onDeposit: () => void;
  onAdmin?: () => void;
  onAccount?: () => void;
}

export function Navbar({ balance, onDeposit, onAdmin, onAccount }: NavbarProps) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <nav className="bg-gray-950 border-b border-gray-800 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-400 to-cyan-500 flex items-center justify-center">
              <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
              </svg>
            </div>
            <span className="text-white font-bold text-xl tracking-tight">Binary<span className="text-emerald-400">Pro</span></span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-6 text-sm text-gray-400">
            <button className="hover:text-white transition-colors text-emerald-400 font-medium">Trading</button>
            <button className="hover:text-white transition-colors">Markets</button>
            <button className="hover:text-white transition-colors">Analytics</button>
            <button className="hover:text-white transition-colors">History</button>
            {onAdmin && (
              <button onClick={onAdmin} className="flex items-center gap-1.5 text-violet-400 hover:text-violet-300 transition-colors font-medium border border-violet-500/30 px-3 py-1 rounded-lg hover:bg-violet-500/10">
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
                Admin
              </button>
            )}
          </div>

          {/* Balance + Deposit */}
          <div className="hidden md:flex items-center gap-3">
            <div className="bg-gray-900 border border-gray-700 rounded-lg px-4 py-2 flex items-center gap-2">
              <svg className="w-4 h-4 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span className="text-white font-semibold">${balance.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
            <button
              onClick={onDeposit}
              className="bg-emerald-500 hover:bg-emerald-400 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors"
            >
              + Deposit
            </button>
            <button
              onClick={onAccount}
              className="w-9 h-9 rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center text-white text-sm font-bold cursor-pointer hover:opacity-80 transition-opacity"
              title="My Account"
            >
              JD
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <button className="md:hidden text-gray-400 hover:text-white" onClick={() => setMenuOpen(!menuOpen)}>
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              {menuOpen
                ? <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                : <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />}
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className={cn("md:hidden border-t border-gray-800 bg-gray-950 transition-all", menuOpen ? "block" : "hidden")}>
        <div className="px-4 py-4 flex flex-col gap-3 text-sm text-gray-400">
          <button className="text-left text-emerald-400 font-medium">Trading</button>
          <button className="text-left hover:text-white">Markets</button>
          <button className="text-left hover:text-white">Analytics</button>
          <button className="text-left hover:text-white">History</button>
          <div className="border-t border-gray-800 pt-3 flex items-center justify-between">
            <span className="text-white font-semibold">${balance.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            <button onClick={onDeposit} className="bg-emerald-500 text-white px-4 py-1.5 rounded-lg text-sm font-semibold">+ Deposit</button>
          </div>
        </div>
      </div>
    </nav>
  );
}
