import { useState } from "react";
import { cn } from "@/utils/cn";

interface ToggleProps {
  enabled: boolean;
  onChange: (v: boolean) => void;
  label: string;
  description?: string;
}

function Toggle({ enabled, onChange, label, description }: ToggleProps) {
  return (
    <div className="flex items-center justify-between py-3">
      <div>
        <div className="text-white text-sm font-medium">{label}</div>
        {description && <div className="text-gray-500 text-xs mt-0.5">{description}</div>}
      </div>
      <button
        onClick={() => onChange(!enabled)}
        className={cn(
          "relative w-11 h-6 rounded-full transition-colors flex-shrink-0",
          enabled ? "bg-violet-600" : "bg-gray-700"
        )}
      >
        <span className={cn("absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform", enabled ? "translate-x-5" : "translate-x-0")} />
      </button>
    </div>
  );
}

export function AdminSettings() {
  const [payoutRates, setPayoutRates] = useState({
    "BTC/USD": 85,
    "ETH/USD": 82,
    "EUR/USD": 80,
    "GBP/USD": 80,
    "XAU/USD": 78,
    "SPX500": 75,
  });

  const [toggles, setToggles] = useState({
    maintenanceMode: false,
    registrationOpen: true,
    kycRequired: true,
    autoWithdrawals: false,
    emailNotifications: true,
    twoFactorRequired: false,
    riskAlerts: true,
    chatSupport: true,
  });

  const [limits, setLimits] = useState({
    minDeposit: 10,
    maxDeposit: 50000,
    minWithdrawal: 20,
    maxWithdrawal: 10000,
    minTrade: 5,
    maxTrade: 5000,
    maxDailyWithdrawal: 25000,
  });

  const [saved, setSaved] = useState(false);

  const setToggle = (key: keyof typeof toggles) => (val: boolean) => {
    setToggles(prev => ({ ...prev, [key]: val }));
  };

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="space-y-5 max-w-4xl">
      <div>
        <h2 className="text-white font-bold text-xl">Platform Settings</h2>
        <p className="text-gray-400 text-sm">Configure platform behavior, limits, and features</p>
      </div>

      {/* System Status */}
      <div className={cn(
        "border rounded-2xl p-4 flex items-center gap-4",
        toggles.maintenanceMode
          ? "bg-red-500/10 border-red-500/20"
          : "bg-emerald-500/10 border-emerald-500/20"
      )}>
        <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center", toggles.maintenanceMode ? "bg-red-500/20" : "bg-emerald-500/20")}>
          <svg className={cn("w-5 h-5", toggles.maintenanceMode ? "text-red-400" : "text-emerald-400")} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </div>
        <div className="flex-1">
          <div className={cn("font-semibold", toggles.maintenanceMode ? "text-red-400" : "text-emerald-400")}>
            {toggles.maintenanceMode ? "🔧 Platform Under Maintenance" : "✅ Platform Online"}
          </div>
          <div className="text-gray-400 text-xs">
            {toggles.maintenanceMode ? "Users cannot access the trading platform" : "All systems operational — users can trade normally"}
          </div>
        </div>
        <button
          onClick={() => setToggle("maintenanceMode")(!toggles.maintenanceMode)}
          className={cn(
            "px-4 py-2 rounded-lg text-sm font-semibold transition-colors",
            toggles.maintenanceMode
              ? "bg-emerald-500 hover:bg-emerald-400 text-white"
              : "bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 text-red-400"
          )}
        >
          {toggles.maintenanceMode ? "Bring Online" : "Enable Maintenance"}
        </button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
        {/* Platform Controls */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <h3 className="text-white font-semibold mb-1">Platform Controls</h3>
          <p className="text-gray-500 text-xs mb-4">Toggle core platform features on or off</p>
          <div className="divide-y divide-gray-800">
            <Toggle enabled={toggles.registrationOpen} onChange={setToggle("registrationOpen")} label="User Registration" description="Allow new users to register accounts" />
            <Toggle enabled={toggles.kycRequired} onChange={setToggle("kycRequired")} label="KYC Required" description="Require identity verification for withdrawals" />
            <Toggle enabled={toggles.autoWithdrawals} onChange={setToggle("autoWithdrawals")} label="Auto-Approve Withdrawals" description="Auto-approve withdrawals under $500" />
            <Toggle enabled={toggles.twoFactorRequired} onChange={setToggle("twoFactorRequired")} label="Force 2FA" description="Require two-factor auth for all users" />
            <Toggle enabled={toggles.riskAlerts} onChange={setToggle("riskAlerts")} label="Risk Alerts" description="Notify admin of high-risk trading activity" />
            <Toggle enabled={toggles.emailNotifications} onChange={setToggle("emailNotifications")} label="Email Notifications" description="Send trade and account email alerts" />
            <Toggle enabled={toggles.chatSupport} onChange={setToggle("chatSupport")} label="Live Chat Support" description="Enable live chat widget for users" />
          </div>
        </div>

        {/* Trading Limits */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <h3 className="text-white font-semibold mb-1">Trading Limits</h3>
          <p className="text-gray-500 text-xs mb-4">Configure min/max values for deposits, withdrawals & trades</p>
          <div className="space-y-3">
            {(Object.entries(limits) as [keyof typeof limits, number][]).map(([key, val]) => {
              const labels: Record<keyof typeof limits, string> = {
                minDeposit: "Min Deposit ($)",
                maxDeposit: "Max Deposit ($)",
                minWithdrawal: "Min Withdrawal ($)",
                maxWithdrawal: "Max Withdrawal ($)",
                minTrade: "Min Trade ($)",
                maxTrade: "Max Trade ($)",
                maxDailyWithdrawal: "Max Daily Withdrawal ($)",
              };
              return (
                <div key={key} className="flex items-center gap-3">
                  <label className="text-gray-400 text-xs w-44 flex-shrink-0">{labels[key]}</label>
                  <div className="relative flex-1">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-sm">$</span>
                    <input
                      type="number"
                      value={val}
                      onChange={e => setLimits(prev => ({ ...prev, [key]: parseFloat(e.target.value) || 0 }))}
                      className="w-full bg-gray-800 border border-gray-700 focus:border-violet-500 text-white rounded-lg pl-7 pr-3 py-2 text-sm outline-none transition-colors"
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Payout Rates */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-white font-semibold">Asset Payout Rates</h3>
            <p className="text-gray-500 text-xs mt-0.5">Configure win payout % for each trading asset</p>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-amber-400 bg-amber-500/10 border border-amber-500/20 rounded-lg px-3 py-1.5">
            ⚠️ Changes affect live users
          </div>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {(Object.entries(payoutRates) as [string, number][]).map(([asset, rate]) => (
            <div key={asset} className="bg-gray-800 rounded-xl p-3">
              <div className="text-white text-sm font-semibold mb-2">{asset}</div>
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min={60}
                  max={95}
                  value={rate}
                  onChange={e => setPayoutRates(prev => ({ ...prev, [asset]: parseInt(e.target.value) }))}
                  className="flex-1 accent-violet-500"
                />
                <span className={cn("text-sm font-bold w-10 text-right", rate >= 80 ? "text-emerald-400" : "text-amber-400")}>{rate}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Admin Accounts */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-white font-semibold">Admin Accounts</h3>
            <p className="text-gray-500 text-xs">Manage admin access and permissions</p>
          </div>
          <button className="bg-violet-600 hover:bg-violet-500 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors">
            + Add Admin
          </button>
        </div>
        <div className="space-y-2">
          {[
            { name: "Super Admin", email: "admin@binarypro.com", role: "Super Admin", status: "active" },
            { name: "Operations Team", email: "ops@binarypro.com", role: "Moderator", status: "active" },
            { name: "Finance Manager", email: "finance@binarypro.com", role: "Finance", status: "active" },
          ].map((a) => (
            <div key={a.email} className="flex items-center gap-3 bg-gray-800 rounded-xl px-4 py-3">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center text-white text-xs font-bold">
                {a.name[0]}
              </div>
              <div className="flex-1">
                <div className="text-white text-sm font-medium">{a.name}</div>
                <div className="text-gray-500 text-xs">{a.email}</div>
              </div>
              <span className="text-xs text-violet-400 bg-violet-500/10 px-2 py-0.5 rounded-full">{a.role}</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            </div>
          ))}
        </div>
      </div>

      {/* Save Button */}
      <div className="flex justify-end">
        <button
          onClick={handleSave}
          className={cn(
            "px-8 py-3 rounded-xl font-bold text-sm transition-all",
            saved
              ? "bg-emerald-500 text-white"
              : "bg-violet-600 hover:bg-violet-500 text-white shadow-lg shadow-violet-500/25"
          )}
        >
          {saved ? "✓ Settings Saved!" : "Save All Changes"}
        </button>
      </div>
    </div>
  );
}
