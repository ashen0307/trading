import { useState, useEffect, useRef } from "react";

interface BarData {
  label: string;
  revenue: number;
  trades: number;
  users: number;
}

const WEEKLY_DATA: BarData[] = [
  { label: "Mon", revenue: 32400, trades: 1840, users: 128 },
  { label: "Tue", revenue: 41200, trades: 2120, users: 145 },
  { label: "Wed", revenue: 38900, trades: 1990, users: 132 },
  { label: "Thu", revenue: 55000, trades: 2540, users: 178 },
  { label: "Fri", revenue: 67300, trades: 3100, users: 210 },
  { label: "Sat", revenue: 48200, trades: 2340, users: 162 },
  { label: "Sun", revenue: 35800, trades: 1780, users: 119 },
];

const ASSET_DIST = [
  { name: "BTC/USD", pct: 35, color: "#f59e0b", trades: 4820 },
  { name: "ETH/USD", pct: 22, color: "#8b5cf6", trades: 3010 },
  { name: "EUR/USD", pct: 18, color: "#10b981", trades: 2470 },
  { name: "XAU/USD", pct: 12, color: "#fbbf24", trades: 1650 },
  { name: "GBP/USD", pct: 8, color: "#3b82f6", trades: 1100 },
  { name: "SPX500", pct: 5, color: "#ec4899", trades: 690 },
];

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"];
const MONTHLY_REVENUE = [180000, 220000, 195000, 310000, 285000, 370000, 430000];
const MONTHLY_USERS = [1200, 1800, 2200, 3100, 3800, 4600, 5800];

function BarChart({ data, metric }: { data: BarData[], metric: keyof BarData }) {
  const max = Math.max(...data.map(d => d[metric] as number));
  return (
    <div className="flex items-end gap-2 h-32">
      {data.map((d, i) => {
        const height = ((d[metric] as number) / max) * 100;
        return (
          <div key={i} className="flex-1 flex flex-col items-center gap-1">
            <div className="w-full relative group" style={{ height: "128px", display: "flex", alignItems: "flex-end" }}>
              <div
                className="w-full rounded-t-md bg-violet-500 hover:bg-violet-400 transition-colors cursor-pointer"
                style={{ height: `${height}%`, minHeight: "4px" }}
              >
                <div className="opacity-0 group-hover:opacity-100 absolute -top-8 left-1/2 -translate-x-1/2 bg-gray-700 text-white text-xs px-2 py-1 rounded whitespace-nowrap transition-opacity z-10">
                  {metric === "revenue" ? `$${(d[metric] as number).toLocaleString()}` : d[metric]}
                </div>
              </div>
            </div>
            <span className="text-gray-500 text-xs">{d.label}</span>
          </div>
        );
      })}
    </div>
  );
}

function LineChart({ data, color }: { data: number[], color: string }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const W = canvas.width, H = canvas.height;
    ctx.clearRect(0, 0, W, H);
    const min = Math.min(...data);
    const max = Math.max(...data);
    const range = max - min;
    const pts = data.map((v, i) => ({
      x: (i / (data.length - 1)) * (W - 20) + 10,
      y: H - 10 - ((v - min) / range) * (H - 20),
    }));
    // gradient fill
    const grad = ctx.createLinearGradient(0, 0, 0, H);
    grad.addColorStop(0, color + "40");
    grad.addColorStop(1, color + "00");
    ctx.beginPath();
    pts.forEach((p, i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
    ctx.lineTo(pts[pts.length - 1].x, H);
    ctx.lineTo(pts[0].x, H);
    ctx.closePath();
    ctx.fillStyle = grad;
    ctx.fill();
    // line
    ctx.beginPath();
    pts.forEach((p, i) => i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y));
    ctx.strokeStyle = color;
    ctx.lineWidth = 2.5;
    ctx.lineJoin = "round";
    ctx.stroke();
    // dots
    pts.forEach(p => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, 3, 0, Math.PI * 2);
      ctx.fillStyle = color;
      ctx.fill();
    });
  }, [data, color]);
  return <canvas ref={canvasRef} width={500} height={120} className="w-full h-28" />;
}

function DonutChart({ segments }: { segments: typeof ASSET_DIST }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const size = canvas.width;
    ctx.clearRect(0, 0, size, size);
    const cx = size / 2, cy = size / 2, r = size / 2 - 10, inner = r * 0.58;
    let angle = -Math.PI / 2;
    segments.forEach(s => {
      const slice = (s.pct / 100) * Math.PI * 2;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, r, angle, angle + slice);
      ctx.closePath();
      ctx.fillStyle = s.color;
      ctx.fill();
      angle += slice;
    });
    // hole
    ctx.beginPath();
    ctx.arc(cx, cy, inner, 0, Math.PI * 2);
    ctx.fillStyle = "#111827";
    ctx.fill();
    // center text
    ctx.fillStyle = "#fff";
    ctx.font = "bold 18px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("100%", cx, cy + 2);
    ctx.fillStyle = "#6b7280";
    ctx.font = "10px sans-serif";
    ctx.fillText("Assets", cx, cy + 16);
  }, [segments]);
  return <canvas ref={canvasRef} width={160} height={160} className="w-40 h-40" />;
}

export function AdminAnalytics() {
  const [metric, setMetric] = useState<"revenue" | "trades" | "users">("revenue");
  const [, setTick] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => setTick(t => t + 1), 5000);
    return () => clearInterval(interval);
  }, []);

  const totalRevenue = MONTHLY_REVENUE.reduce((a, b) => a + b, 0);
  const totalTrades = WEEKLY_DATA.reduce((s, d) => s + d.trades, 0);
  const avgWinRate = 54;

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-white font-bold text-xl">Analytics & Reports</h2>
        <p className="text-gray-400 text-sm">Platform performance metrics and insights</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        {[
          { label: "Monthly Revenue", value: `$${(totalRevenue / 1000).toFixed(0)}K`, sub: "+22% vs last month", color: "text-emerald-400", icon: "💰" },
          { label: "Total Trades (7d)", value: totalTrades.toLocaleString(), sub: `${Math.round(totalTrades / 7)} avg/day`, color: "text-cyan-400", icon: "📊" },
          { label: "Platform Win Rate", value: `${avgWinRate}%`, sub: "House edge: 46%", color: "text-violet-400", icon: "🎯" },
          { label: "New Users (7d)", value: "1,074", sub: "+18% vs prev week", color: "text-amber-400", icon: "👥" },
        ].map(k => (
          <div key={k.label} className="bg-gray-900 border border-gray-800 rounded-2xl p-4">
            <div className="text-2xl mb-1">{k.icon}</div>
            <div className={`text-2xl font-bold ${k.color}`}>{k.value}</div>
            <div className="text-gray-400 text-xs mt-0.5">{k.label}</div>
            <div className="text-gray-600 text-xs">{k.sub}</div>
          </div>
        ))}
      </div>

      {/* Weekly Bar Chart */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-white font-semibold">Weekly Performance</h3>
          <div className="flex gap-1">
            {(["revenue", "trades", "users"] as const).map(m => (
              <button
                key={m}
                onClick={() => setMetric(m)}
                className={`px-3 py-1 rounded-lg text-xs font-semibold capitalize transition-all ${metric === m ? "bg-violet-600 text-white" : "bg-gray-800 text-gray-400 hover:text-white"}`}
              >
                {m}
              </button>
            ))}
          </div>
        </div>
        <BarChart data={WEEKLY_DATA} metric={metric} />
      </div>

      {/* Revenue Trend + Asset Distribution */}
      <div className="grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-4">
        {/* Monthly Revenue Trend */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-1">
            <h3 className="text-white font-semibold">Revenue Trend (7 Months)</h3>
            <span className="text-emerald-400 text-sm font-semibold">▲ 139% Growth</span>
          </div>
          <div className="flex gap-6 text-xs text-gray-500 mb-3">
            {MONTHS.map((m, i) => (
              <span key={m} className={i === MONTHS.length - 1 ? "text-emerald-400 font-semibold" : ""}>{m}</span>
            ))}
          </div>
          <LineChart data={MONTHLY_REVENUE} color="#10b981" />
          <div className="flex gap-6 mt-2">
            {MONTHS.map((m, i) => (
              <span key={m} className="text-gray-600 text-xs flex-1 text-center hidden md:block">${(MONTHLY_REVENUE[i] / 1000).toFixed(0)}K</span>
            ))}
          </div>
        </div>

        {/* Asset Distribution */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <h3 className="text-white font-semibold mb-4">Asset Distribution</h3>
          <div className="flex items-center gap-4">
            <DonutChart segments={ASSET_DIST} />
            <div className="flex-1 space-y-2">
              {ASSET_DIST.map(a => (
                <div key={a.name} className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: a.color }} />
                  <span className="text-gray-300 text-xs flex-1">{a.name}</span>
                  <span className="text-white text-xs font-bold">{a.pct}%</span>
                </div>
              ))}
            </div>
          </div>
          <div className="mt-4 space-y-2">
            {ASSET_DIST.slice(0, 3).map(a => (
              <div key={a.name}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-gray-400">{a.name}</span>
                  <span className="text-gray-400">{a.trades.toLocaleString()} trades</span>
                </div>
                <div className="bg-gray-700 rounded-full h-1.5">
                  <div className="h-1.5 rounded-full" style={{ width: `${a.pct}%`, background: a.color }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* User Growth */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <div className="flex items-center justify-between mb-1">
          <h3 className="text-white font-semibold">User Growth (7 Months)</h3>
          <span className="text-violet-400 text-sm font-semibold">▲ 383% Growth</span>
        </div>
        <div className="flex gap-6 text-xs text-gray-500 mb-3">
          {MONTHS.map(m => <span key={m}>{m}</span>)}
        </div>
        <LineChart data={MONTHLY_USERS} color="#8b5cf6" />
      </div>
    </div>
  );
}
