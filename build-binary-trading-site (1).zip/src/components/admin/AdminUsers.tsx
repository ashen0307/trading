import { useState } from "react";
import { cn } from "@/utils/cn";

interface User {
  id: string;
  name: string;
  email: string;
  country: string;
  balance: number;
  totalDeposits: number;
  totalTrades: number;
  winRate: number;
  status: "active" | "suspended" | "pending";
  kyc: "verified" | "pending" | "rejected" | "none";
  joined: string;
  lastActive: string;
}

const USERS: User[] = [
  { id: "U001", name: "John Doe", email: "john.doe@email.com", country: "🇺🇸 USA", balance: 2450.80, totalDeposits: 5000, totalTrades: 342, winRate: 62, status: "active", kyc: "verified", joined: "Jan 12, 2024", lastActive: "2m ago" },
  { id: "U002", name: "Maria Garcia", email: "maria.g@email.com", country: "🇪🇸 Spain", balance: 8920.50, totalDeposits: 12000, totalTrades: 215, winRate: 68, status: "active", kyc: "verified", joined: "Feb 3, 2024", lastActive: "5m ago" },
  { id: "U003", name: "Alex Kim", email: "alex.k@email.com", country: "🇰🇷 Korea", balance: 450.00, totalDeposits: 1000, totalTrades: 89, winRate: 45, status: "suspended", kyc: "verified", joined: "Mar 17, 2024", lastActive: "2d ago" },
  { id: "U004", name: "Linda Hassan", email: "linda.h@email.com", country: "🇦🇪 UAE", balance: 15200.00, totalDeposits: 20000, totalTrades: 512, winRate: 71, status: "active", kyc: "verified", joined: "Nov 5, 2023", lastActive: "Just now" },
  { id: "U005", name: "Ben Walker", email: "ben.w@email.com", country: "🇬🇧 UK", balance: 320.00, totalDeposits: 500, totalTrades: 23, winRate: 39, status: "pending", kyc: "pending", joined: "Apr 22, 2024", lastActive: "1h ago" },
  { id: "U006", name: "Sophie Martin", email: "sophie.m@email.com", country: "🇫🇷 France", balance: 5670.00, totalDeposits: 8000, totalTrades: 134, winRate: 60, status: "active", kyc: "verified", joined: "Dec 10, 2023", lastActive: "20m ago" },
  { id: "U007", name: "Raj Patel", email: "raj.p@email.com", country: "🇮🇳 India", balance: 1800.00, totalDeposits: 3000, totalTrades: 290, winRate: 55, status: "active", kyc: "pending", joined: "Jan 30, 2024", lastActive: "1d ago" },
  { id: "U008", name: "Emma Wilson", email: "emma.w@email.com", country: "🇨🇦 Canada", balance: 0, totalDeposits: 200, totalTrades: 10, winRate: 30, status: "suspended", kyc: "rejected", joined: "Mar 1, 2024", lastActive: "5d ago" },
];

const statusStyle: Record<string, string> = {
  active: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  suspended: "bg-red-500/10 text-red-400 border-red-500/20",
  pending: "bg-amber-500/10 text-amber-400 border-amber-500/20",
};

const kycStyle: Record<string, string> = {
  verified: "bg-emerald-500/10 text-emerald-400",
  pending: "bg-amber-500/10 text-amber-400",
  rejected: "bg-red-500/10 text-red-400",
  none: "bg-gray-700 text-gray-400",
};

export function AdminUsers() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  const filtered = USERS.filter(u => {
    const matchSearch = u.name.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase()) || u.id.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || u.status === statusFilter;
    return matchSearch && matchStatus;
  });

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-white font-bold text-xl">User Management</h2>
          <p className="text-gray-400 text-sm">{USERS.length} total users registered</p>
        </div>
        <button className="bg-violet-600 hover:bg-violet-500 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors flex items-center gap-2">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
          </svg>
          Export CSV
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input
            type="text"
            placeholder="Search users..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full bg-gray-900 border border-gray-800 focus:border-violet-500 text-white rounded-xl pl-10 pr-4 py-2.5 text-sm outline-none transition-colors"
          />
        </div>
        <div className="flex gap-2">
          {["all", "active", "suspended", "pending"].map(s => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={cn(
                "px-3 py-2 rounded-lg text-sm font-medium capitalize transition-all",
                statusFilter === s ? "bg-violet-600 text-white" : "bg-gray-900 border border-gray-800 text-gray-400 hover:text-white"
              )}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-800">
                <th className="text-left text-gray-400 font-medium px-4 py-3">User</th>
                <th className="text-left text-gray-400 font-medium px-4 py-3 hidden md:table-cell">Country</th>
                <th className="text-right text-gray-400 font-medium px-4 py-3">Balance</th>
                <th className="text-right text-gray-400 font-medium px-4 py-3 hidden lg:table-cell">Trades</th>
                <th className="text-center text-gray-400 font-medium px-4 py-3 hidden lg:table-cell">Win Rate</th>
                <th className="text-center text-gray-400 font-medium px-4 py-3">KYC</th>
                <th className="text-center text-gray-400 font-medium px-4 py-3">Status</th>
                <th className="text-center text-gray-400 font-medium px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {filtered.map(user => (
                <tr key={user.id} className="hover:bg-gray-800/40 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                        {user.name.split(" ").map(n => n[0]).join("")}
                      </div>
                      <div>
                        <div className="text-white font-medium">{user.name}</div>
                        <div className="text-gray-500 text-xs">{user.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-gray-300 hidden md:table-cell">{user.country}</td>
                  <td className="px-4 py-3 text-right">
                    <div className="text-white font-mono font-semibold">${user.balance.toLocaleString("en-US", { minimumFractionDigits: 2 })}</div>
                    <div className="text-gray-500 text-xs">${user.totalDeposits.toLocaleString()} deposited</div>
                  </td>
                  <td className="px-4 py-3 text-right text-gray-300 hidden lg:table-cell">{user.totalTrades}</td>
                  <td className="px-4 py-3 hidden lg:table-cell">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-gray-700 rounded-full h-1.5">
                        <div className={cn("h-1.5 rounded-full", user.winRate >= 55 ? "bg-emerald-500" : "bg-amber-500")} style={{ width: `${user.winRate}%` }} />
                      </div>
                      <span className="text-gray-400 text-xs w-8">{user.winRate}%</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${kycStyle[user.kyc]}`}>
                      {user.kyc.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span className={`text-xs font-semibold px-2 py-1 rounded-full border capitalize ${statusStyle[user.status]}`}>
                      {user.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <button onClick={() => setSelectedUser(user)} className="p-1.5 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg transition-colors" title="View">
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                          <path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                        </svg>
                      </button>
                      <button className="p-1.5 text-gray-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-colors" title="Suspend">
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                        </svg>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* User Detail Modal */}
      {selectedUser && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setSelectedUser(null)}>
          <div className="bg-gray-900 border border-gray-700 rounded-2xl w-full max-w-lg" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-gray-800">
              <h3 className="text-white font-bold text-lg">User Profile</h3>
              <button onClick={() => setSelectedUser(null)} className="text-gray-500 hover:text-white">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center text-white text-xl font-bold">
                  {selectedUser.name.split(" ").map(n => n[0]).join("")}
                </div>
                <div>
                  <div className="text-white font-bold text-xl">{selectedUser.name}</div>
                  <div className="text-gray-400 text-sm">{selectedUser.email}</div>
                  <div className="text-gray-500 text-xs mt-1">ID: {selectedUser.id} · {selectedUser.country}</div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: "Balance", value: `$${selectedUser.balance.toFixed(2)}` },
                  { label: "Total Deposits", value: `$${selectedUser.totalDeposits.toLocaleString()}` },
                  { label: "Total Trades", value: selectedUser.totalTrades },
                  { label: "Win Rate", value: `${selectedUser.winRate}%` },
                  { label: "Joined", value: selectedUser.joined },
                  { label: "Last Active", value: selectedUser.lastActive },
                ].map(item => (
                  <div key={item.label} className="bg-gray-800 rounded-xl p-3">
                    <div className="text-gray-400 text-xs">{item.label}</div>
                    <div className="text-white font-semibold mt-0.5">{item.value}</div>
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <button className="flex-1 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 text-emerald-400 text-sm font-semibold py-2.5 rounded-xl transition-colors">Activate</button>
                <button className="flex-1 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 text-amber-400 text-sm font-semibold py-2.5 rounded-xl transition-colors">Suspend</button>
                <button className="flex-1 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 text-sm font-semibold py-2.5 rounded-xl transition-colors">Ban</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
