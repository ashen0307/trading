import { useState } from "react";
import { cn } from "@/utils/cn";

interface Withdrawal {
  id: string;
  user: string;
  email: string;
  amount: number;
  method: string;
  account: string;
  status: "pending" | "approved" | "rejected" | "processing";
  requested: string;
  country: string;
}

const WITHDRAWALS: Withdrawal[] = [
  { id: "W001", user: "Maria Garcia", email: "maria.g@email.com", amount: 1500, method: "Bank Transfer", account: "****4523", status: "pending", requested: "2 min ago", country: "🇪🇸" },
  { id: "W002", user: "John Doe", email: "john.doe@email.com", amount: 850, method: "Crypto (BTC)", account: "1A2b3...9Xyz", status: "pending", requested: "15 min ago", country: "🇺🇸" },
  { id: "W003", user: "Linda Hassan", email: "linda.h@email.com", amount: 3200, method: "Bank Transfer", account: "****7891", status: "processing", requested: "1h ago", country: "🇦🇪" },
  { id: "W004", user: "Raj Patel", email: "raj.p@email.com", amount: 800, method: "Crypto (ETH)", account: "0xAb12...Cd34", status: "pending", requested: "2h ago", country: "🇮🇳" },
  { id: "W005", user: "Sophie Martin", email: "sophie.m@email.com", amount: 600, method: "Credit Card", account: "****3344", status: "approved", requested: "3h ago", country: "🇫🇷" },
  { id: "W006", user: "Trader X", email: "trader.x@email.com", amount: 5000, method: "Bank Transfer", account: "****2201", status: "approved", requested: "4h ago", country: "🇩🇪" },
  { id: "W007", user: "Emma Wilson", email: "emma.w@email.com", amount: 200, method: "Crypto (BTC)", account: "3J98t...kLM4", status: "rejected", requested: "5h ago", country: "🇨🇦" },
];

const statusStyle: Record<string, string> = {
  pending: "bg-amber-500/10 text-amber-400 border-amber-500/20",
  approved: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  rejected: "bg-red-500/10 text-red-400 border-red-500/20",
  processing: "bg-blue-500/10 text-blue-400 border-blue-500/20",
};

const methodIcon: Record<string, string> = {
  "Bank Transfer": "🏦",
  "Crypto (BTC)": "₿",
  "Crypto (ETH)": "Ξ",
  "Credit Card": "💳",
};

export function AdminWithdrawals() {
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>(WITHDRAWALS);
  const [statusFilter, setStatusFilter] = useState("all");
  const [selected, setSelected] = useState<Withdrawal | null>(null);

  const filtered = withdrawals.filter(w => statusFilter === "all" || w.status === statusFilter);
  const pendingTotal = withdrawals.filter(w => w.status === "pending").reduce((s, w) => s + w.amount, 0);
  const pendingCount = withdrawals.filter(w => w.status === "pending").length;

  const handleAction = (id: string, action: "approved" | "rejected") => {
    setWithdrawals(prev => prev.map(w => w.id === id ? { ...w, status: action } : w));
    setSelected(null);
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-white font-bold text-xl">Withdrawal Requests</h2>
          <p className="text-gray-400 text-sm">{pendingCount} pending · ${pendingTotal.toLocaleString()} total pending</p>
        </div>
        <div className="flex items-center gap-2">
          {pendingCount > 0 && (
            <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl px-4 py-2 flex items-center gap-2">
              <svg className="w-4 h-4 text-amber-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              <span className="text-amber-400 text-sm font-semibold">{pendingCount} Pending Review</span>
            </div>
          )}
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: "Pending", value: withdrawals.filter(w => w.status === "pending").length, color: "text-amber-400", bg: "bg-amber-500/10 border-amber-500/20" },
          { label: "Processing", value: withdrawals.filter(w => w.status === "processing").length, color: "text-blue-400", bg: "bg-blue-500/10 border-blue-500/20" },
          { label: "Approved Today", value: withdrawals.filter(w => w.status === "approved").length, color: "text-emerald-400", bg: "bg-emerald-500/10 border-emerald-500/20" },
          { label: "Rejected", value: withdrawals.filter(w => w.status === "rejected").length, color: "text-red-400", bg: "bg-red-500/10 border-red-500/20" },
        ].map(s => (
          <div key={s.label} className={`border rounded-xl px-4 py-3 text-center ${s.bg}`}>
            <div className={`text-2xl font-bold ${s.color}`}>{s.value}</div>
            <div className="text-gray-400 text-xs mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex gap-2 flex-wrap">
        {["all", "pending", "processing", "approved", "rejected"].map(s => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all",
              statusFilter === s ? "bg-violet-600 text-white" : "bg-gray-900 border border-gray-800 text-gray-400 hover:text-white"
            )}
          >
            {s}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-800">
                <th className="text-left text-gray-400 font-medium px-4 py-3">User</th>
                <th className="text-left text-gray-400 font-medium px-4 py-3 hidden md:table-cell">Method</th>
                <th className="text-right text-gray-400 font-medium px-4 py-3">Amount</th>
                <th className="text-center text-gray-400 font-medium px-4 py-3">Status</th>
                <th className="text-right text-gray-400 font-medium px-4 py-3 hidden lg:table-cell">Requested</th>
                <th className="text-center text-gray-400 font-medium px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {filtered.map(w => (
                <tr key={w.id} className="hover:bg-gray-800/40 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-gray-600 to-gray-700 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                        {w.user.split(" ").map(n => n[0]).join("")}
                      </div>
                      <div>
                        <div className="flex items-center gap-1">
                          <span className="text-white font-medium">{w.user}</span>
                          <span>{w.country}</span>
                        </div>
                        <div className="text-gray-500 text-xs">{w.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 hidden md:table-cell">
                    <div className="flex items-center gap-2 text-gray-300">
                      <span>{methodIcon[w.method] || "💰"}</span>
                      <div>
                        <div className="text-sm">{w.method}</div>
                        <div className="text-gray-500 text-xs font-mono">{w.account}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="text-white font-bold text-base">${w.amount.toLocaleString()}</div>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span className={cn("text-xs font-semibold px-2 py-1 rounded-full border capitalize", statusStyle[w.status])}>
                      {w.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right text-gray-500 text-xs hidden lg:table-cell">{w.requested}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center gap-1">
                      <button onClick={() => setSelected(w)} className="p-1.5 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg transition-colors" title="View Details">
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                          <path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                        </svg>
                      </button>
                      {w.status === "pending" && (
                        <>
                          <button onClick={() => handleAction(w.id, "approved")} className="p-1.5 text-gray-400 hover:text-emerald-400 hover:bg-emerald-500/10 rounded-lg transition-colors" title="Approve">
                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                            </svg>
                          </button>
                          <button onClick={() => handleAction(w.id, "rejected")} className="p-1.5 text-gray-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors" title="Reject">
                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Modal */}
      {selected && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setSelected(null)}>
          <div className="bg-gray-900 border border-gray-700 rounded-2xl w-full max-w-md" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b border-gray-800">
              <h3 className="text-white font-bold text-lg">Withdrawal Details</h3>
              <button onClick={() => setSelected(null)} className="text-gray-500 hover:text-white">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-gray-400 text-sm">Request ID</span>
                <span className="text-white font-mono">{selected.id}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400 text-sm">User</span>
                <span className="text-white">{selected.user}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400 text-sm">Amount</span>
                <span className="text-white font-bold text-lg">${selected.amount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400 text-sm">Method</span>
                <span className="text-white">{methodIcon[selected.method]} {selected.method}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400 text-sm">Account</span>
                <span className="text-white font-mono">{selected.account}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400 text-sm">Requested</span>
                <span className="text-white">{selected.requested}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400 text-sm">Status</span>
                <span className={cn("text-xs font-semibold px-2 py-1 rounded-full border capitalize", statusStyle[selected.status])}>{selected.status}</span>
              </div>
              {selected.status === "pending" && (
                <div className="flex gap-3 pt-2">
                  <button onClick={() => handleAction(selected.id, "approved")} className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-white font-bold py-3 rounded-xl transition-colors">
                    ✓ Approve
                  </button>
                  <button onClick={() => handleAction(selected.id, "rejected")} className="flex-1 bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 text-red-400 font-bold py-3 rounded-xl transition-colors">
                    ✕ Reject
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
