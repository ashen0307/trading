import { useState } from "react";
import { cn } from "@/utils/cn";

interface KYCApplication {
  id: string;
  user: string;
  email: string;
  country: string;
  dob: string;
  submittedAt: string;
  status: "pending" | "approved" | "rejected" | "under_review";
  documents: { type: string; url: string; verified: boolean }[];
  riskLevel: "low" | "medium" | "high";
  notes: string;
  idNumber: string;
  phone: string;
  address: string;
}

const KYC_DATA: KYCApplication[] = [
  {
    id: "KYC001", user: "Ben Walker", email: "ben.w@email.com", country: "🇬🇧 United Kingdom",
    dob: "1990-06-15", submittedAt: "2024-04-22 09:14", status: "pending",
    documents: [
      { type: "Passport", url: "passport_001.jpg", verified: false },
      { type: "Selfie", url: "selfie_001.jpg", verified: false },
      { type: "Proof of Address", url: "address_001.pdf", verified: false },
    ],
    riskLevel: "low", notes: "", idNumber: "GB123456789", phone: "+44 7700 900123",
    address: "12 Oxford Street, London, W1D 1NN",
  },
  {
    id: "KYC002", user: "Raj Patel", email: "raj.p@email.com", country: "🇮🇳 India",
    dob: "1985-11-22", submittedAt: "2024-04-21 14:30", status: "under_review",
    documents: [
      { type: "National ID", url: "nid_002.jpg", verified: true },
      { type: "Selfie", url: "selfie_002.jpg", verified: true },
      { type: "Bank Statement", url: "bank_002.pdf", verified: false },
    ],
    riskLevel: "medium", notes: "Address document slightly blurry — requested resubmission", idNumber: "IN987654321", phone: "+91 98765 43210",
    address: "45 MG Road, Mumbai, Maharashtra 400001",
  },
  {
    id: "KYC003", user: "Lena Fischer", email: "lena.f@email.com", country: "🇩🇪 Germany",
    dob: "1993-03-08", submittedAt: "2024-04-20 11:05", status: "pending",
    documents: [
      { type: "Driver's License", url: "dl_003.jpg", verified: false },
      { type: "Selfie", url: "selfie_003.jpg", verified: false },
      { type: "Utility Bill", url: "bill_003.pdf", verified: false },
    ],
    riskLevel: "low", notes: "", idNumber: "DE654321098", phone: "+49 170 1234567",
    address: "Kurfürstendamm 12, 10719 Berlin",
  },
  {
    id: "KYC004", user: "Carlos Mendoza", email: "carlos.m@email.com", country: "🇲🇽 Mexico",
    dob: "1978-09-30", submittedAt: "2024-04-19 16:45", status: "pending",
    documents: [
      { type: "Passport", url: "passport_004.jpg", verified: false },
      { type: "Selfie", url: "selfie_004.jpg", verified: false },
    ],
    riskLevel: "high", notes: "High deposit activity — requires enhanced due diligence", idNumber: "MX234567890", phone: "+52 55 1234 5678",
    address: "Av. Insurgentes Sur 1234, CDMX 03920",
  },
  {
    id: "KYC005", user: "Yuki Tanaka", email: "yuki.t@email.com", country: "🇯🇵 Japan",
    dob: "1995-07-14", submittedAt: "2024-04-18 08:22", status: "approved",
    documents: [
      { type: "My Number Card", url: "mnc_005.jpg", verified: true },
      { type: "Selfie", url: "selfie_005.jpg", verified: true },
      { type: "Residence Certificate", url: "res_005.pdf", verified: true },
    ],
    riskLevel: "low", notes: "All documents verified successfully", idNumber: "JP112233445", phone: "+81 90 1234 5678",
    address: "1-1-1 Shinjuku, Tokyo 160-0022",
  },
  {
    id: "KYC006", user: "Emma Wilson", email: "emma.w@email.com", country: "🇨🇦 Canada",
    dob: "1988-02-19", submittedAt: "2024-04-17 13:55", status: "rejected",
    documents: [
      { type: "Driver's License", url: "dl_006.jpg", verified: false },
      { type: "Selfie", url: "selfie_006.jpg", verified: false },
    ],
    riskLevel: "high", notes: "Document expired. Selfie did not match ID photo. Account flagged.", idNumber: "CA556677889", phone: "+1 416 555 0199",
    address: "200 Bay Street, Toronto ON M5J 2J3",
  },
  {
    id: "KYC007", user: "Amara Diallo", email: "amara.d@email.com", country: "🇸🇳 Senegal",
    dob: "2000-01-05", submittedAt: "2024-04-22 07:00", status: "pending",
    documents: [
      { type: "National ID", url: "nid_007.jpg", verified: false },
      { type: "Selfie", url: "selfie_007.jpg", verified: false },
      { type: "Proof of Address", url: "address_007.pdf", verified: false },
    ],
    riskLevel: "medium", notes: "", idNumber: "SN667788990", phone: "+221 77 123 4567",
    address: "Rue Carnot, Dakar, BP 10000",
  },
];

const statusStyle: Record<string, string> = {
  pending: "bg-amber-500/10 text-amber-400 border-amber-500/20",
  approved: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  rejected: "bg-red-500/10 text-red-400 border-red-500/20",
  under_review: "bg-blue-500/10 text-blue-400 border-blue-500/20",
};

const riskStyle: Record<string, string> = {
  low: "text-emerald-400 bg-emerald-500/10",
  medium: "text-amber-400 bg-amber-500/10",
  high: "text-red-400 bg-red-500/10",
};

const statusLabel: Record<string, string> = {
  pending: "Pending",
  approved: "Approved",
  rejected: "Rejected",
  under_review: "Under Review",
};

function DocIcon({ type }: { type: string }) {
  const icons: Record<string, string> = {
    "Passport": "🛂",
    "Selfie": "🤳",
    "Proof of Address": "🏠",
    "National ID": "🪪",
    "Bank Statement": "🏦",
    "Driver's License": "🚗",
    "Utility Bill": "📄",
    "My Number Card": "🪪",
    "Residence Certificate": "📋",
  };
  return <span>{icons[type] || "📁"}</span>;
}

export function AdminKYC() {
  const [applications, setApplications] = useState<KYCApplication[]>(KYC_DATA);
  const [statusFilter, setStatusFilter] = useState("all");
  const [riskFilter, setRiskFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<KYCApplication | null>(null);
  const [noteInput, setNoteInput] = useState("");
  const [docVerified, setDocVerified] = useState<Record<string, boolean>>({});
  const [confirmAction, setConfirmAction] = useState<{ id: string; action: "approved" | "rejected" } | null>(null);

  const filtered = applications.filter(a => {
    const matchStatus = statusFilter === "all" || a.status === statusFilter;
    const matchRisk = riskFilter === "all" || a.riskLevel === riskFilter;
    const matchSearch = a.user.toLowerCase().includes(search.toLowerCase()) ||
      a.email.toLowerCase().includes(search.toLowerCase()) ||
      a.id.toLowerCase().includes(search.toLowerCase());
    return matchStatus && matchRisk && matchSearch;
  });

  const counts = {
    pending: applications.filter(a => a.status === "pending").length,
    under_review: applications.filter(a => a.status === "under_review").length,
    approved: applications.filter(a => a.status === "approved").length,
    rejected: applications.filter(a => a.status === "rejected").length,
  };

  const handleAction = (id: string, action: "approved" | "rejected" | "under_review") => {
    setApplications(prev => prev.map(a => a.id === id
      ? { ...a, status: action, notes: noteInput || a.notes }
      : a
    ));
    setSelected(null);
    setNoteInput("");
    setConfirmAction(null);
  };

  const handleDocVerify = (appId: string, docIdx: number, val: boolean) => {
    const key = `${appId}-${docIdx}`;
    setDocVerified(prev => ({ ...prev, [key]: val }));
    setApplications(prev => prev.map(a => {
      if (a.id !== appId) return a;
      const docs = a.documents.map((d, i) => i === docIdx ? { ...d, verified: val } : d);
      return { ...a, documents: docs };
    }));
  };

  const openSelected = (app: KYCApplication) => {
    setSelected(app);
    setNoteInput(app.notes);
    const init: Record<string, boolean> = {};
    app.documents.forEach((d, i) => { init[`${app.id}-${i}`] = d.verified; });
    setDocVerified(prev => ({ ...prev, ...init }));
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-white font-bold text-xl">KYC Verification Center</h2>
          <p className="text-gray-400 text-sm">Review and manage identity verification submissions</p>
        </div>
        <div className="flex items-center gap-2">
          {counts.pending > 0 && (
            <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl px-4 py-2 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
              <span className="text-amber-400 text-sm font-semibold">{counts.pending} Pending Review</span>
            </div>
          )}
        </div>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: "Pending", value: counts.pending, color: "text-amber-400", bg: "bg-amber-500/10 border-amber-500/20", icon: "⏳" },
          { label: "Under Review", value: counts.under_review, color: "text-blue-400", bg: "bg-blue-500/10 border-blue-500/20", icon: "🔍" },
          { label: "Approved", value: counts.approved, color: "text-emerald-400", bg: "bg-emerald-500/10 border-emerald-500/20", icon: "✅" },
          { label: "Rejected", value: counts.rejected, color: "text-red-400", bg: "bg-red-500/10 border-red-500/20", icon: "❌" },
        ].map(s => (
          <div key={s.label} className={`border rounded-2xl p-4 text-center ${s.bg}`}>
            <div className="text-2xl mb-1">{s.icon}</div>
            <div className={`text-2xl font-bold ${s.color}`}>{s.value}</div>
            <div className="text-gray-400 text-xs mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input
            type="text"
            placeholder="Search by name, email or KYC ID..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full bg-gray-900 border border-gray-800 focus:border-violet-500 text-white rounded-xl pl-10 pr-4 py-2.5 text-sm outline-none transition-colors"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          {["all", "pending", "under_review", "approved", "rejected"].map(s => (
            <button key={s} onClick={() => setStatusFilter(s)}
              className={cn("px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all",
                statusFilter === s ? "bg-violet-600 text-white" : "bg-gray-900 border border-gray-800 text-gray-400 hover:text-white"
              )}>
              {s === "under_review" ? "Under Review" : s.charAt(0).toUpperCase() + s.slice(1)}
            </button>
          ))}
        </div>
        <div className="flex gap-2">
          {["all", "low", "medium", "high"].map(r => (
            <button key={r} onClick={() => setRiskFilter(r)}
              className={cn("px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all",
                riskFilter === r ? "bg-violet-600 text-white" : "bg-gray-900 border border-gray-800 text-gray-400 hover:text-white"
              )}>
              {r === "all" ? "All Risk" : `${r.charAt(0).toUpperCase() + r.slice(1)} Risk`}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-800">
                <th className="text-left text-gray-400 font-medium px-4 py-3">Applicant</th>
                <th className="text-left text-gray-400 font-medium px-4 py-3 hidden md:table-cell">Country</th>
                <th className="text-left text-gray-400 font-medium px-4 py-3 hidden lg:table-cell">Documents</th>
                <th className="text-center text-gray-400 font-medium px-4 py-3">Risk</th>
                <th className="text-center text-gray-400 font-medium px-4 py-3">Status</th>
                <th className="text-left text-gray-400 font-medium px-4 py-3 hidden xl:table-cell">Submitted</th>
                <th className="text-center text-gray-400 font-medium px-4 py-3">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {filtered.map(app => {
                const verifiedCount = app.documents.filter(d => d.verified).length;
                return (
                  <tr key={app.id} className="hover:bg-gray-800/40 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                          {app.user.split(" ").map(n => n[0]).join("")}
                        </div>
                        <div>
                          <div className="text-white font-medium">{app.user}</div>
                          <div className="text-gray-500 text-xs">{app.email}</div>
                          <div className="text-gray-600 text-xs font-mono">{app.id}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-gray-300 text-sm hidden md:table-cell">{app.country}</td>
                    <td className="px-4 py-3 hidden lg:table-cell">
                      <div className="flex items-center gap-1.5">
                        <div className="flex gap-1">
                          {app.documents.map((d, i) => (
                            <span key={i} className={cn("w-5 h-5 rounded-full text-xs flex items-center justify-center",
                              d.verified ? "bg-emerald-500/20 text-emerald-400" : "bg-gray-700 text-gray-400"
                            )} title={d.type}>
                              {d.verified ? "✓" : "·"}
                            </span>
                          ))}
                        </div>
                        <span className="text-gray-500 text-xs">{verifiedCount}/{app.documents.length}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className={cn("text-xs font-semibold px-2 py-0.5 rounded-full capitalize", riskStyle[app.riskLevel])}>
                        {app.riskLevel}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className={cn("text-xs font-semibold px-2 py-1 rounded-full border capitalize", statusStyle[app.status])}>
                        {statusLabel[app.status]}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-gray-500 text-xs hidden xl:table-cell">{app.submittedAt}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1.5">
                        <button onClick={() => openSelected(app)}
                          className="px-3 py-1.5 bg-violet-600/20 hover:bg-violet-600/40 text-violet-400 text-xs font-semibold rounded-lg transition-colors border border-violet-500/20">
                          Review
                        </button>
                        {app.status === "pending" && (
                          <>
                            <button onClick={() => { setSelected(app); setNoteInput(app.notes); setConfirmAction({ id: app.id, action: "approved" }); }}
                              className="p-1.5 text-gray-400 hover:text-emerald-400 hover:bg-emerald-500/10 rounded-lg transition-colors" title="Quick Approve">
                              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                              </svg>
                            </button>
                            <button onClick={() => { setSelected(app); setNoteInput(app.notes); setConfirmAction({ id: app.id, action: "rejected" }); }}
                              className="p-1.5 text-gray-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors" title="Quick Reject">
                              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                              </svg>
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="py-16 text-center text-gray-600">
              <div className="text-4xl mb-2">🔍</div>
              <p className="text-sm">No KYC applications found</p>
            </div>
          )}
        </div>
      </div>

      {/* Confirm Quick Action Modal */}
      {confirmAction && !selected?.id && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-gray-900 border border-gray-700 rounded-2xl w-full max-w-sm p-6 text-center">
            <div className={cn("w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4",
              confirmAction.action === "approved" ? "bg-emerald-500/20" : "bg-red-500/20"
            )}>
              <span className="text-3xl">{confirmAction.action === "approved" ? "✅" : "❌"}</span>
            </div>
            <h3 className="text-white font-bold text-lg mb-2">
              {confirmAction.action === "approved" ? "Approve KYC?" : "Reject KYC?"}
            </h3>
            <p className="text-gray-400 text-sm mb-4">This action will update the user's verification status.</p>
            <textarea value={noteInput} onChange={e => setNoteInput(e.target.value)}
              placeholder="Add a note (optional)..."
              className="w-full bg-gray-800 border border-gray-700 focus:border-violet-500 text-white rounded-xl p-3 text-sm outline-none mb-4 resize-none h-20" />
            <div className="flex gap-3">
              <button onClick={() => setConfirmAction(null)} className="flex-1 bg-gray-800 hover:bg-gray-700 text-gray-300 font-semibold py-2.5 rounded-xl transition-colors">
                Cancel
              </button>
              <button onClick={() => handleAction(confirmAction.id, confirmAction.action)}
                className={cn("flex-1 font-bold py-2.5 rounded-xl transition-colors",
                  confirmAction.action === "approved"
                    ? "bg-emerald-500 hover:bg-emerald-400 text-white"
                    : "bg-red-500 hover:bg-red-400 text-white"
                )}>
                Confirm {confirmAction.action === "approved" ? "Approve" : "Reject"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Detailed Review Modal */}
      {selected && !confirmAction && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setSelected(null)}>
          <div className="bg-gray-900 border border-gray-700 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            {/* Modal Header */}
            <div className="flex items-center justify-between p-5 border-b border-gray-800 sticky top-0 bg-gray-900 z-10">
              <div>
                <h3 className="text-white font-bold text-lg">KYC Review — {selected.user}</h3>
                <p className="text-gray-500 text-xs mt-0.5">{selected.id} · Submitted {selected.submittedAt}</p>
              </div>
              <button onClick={() => setSelected(null)} className="text-gray-500 hover:text-white p-1 rounded-lg hover:bg-gray-800 transition-colors">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="p-5 space-y-5">
              {/* User Info */}
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2 flex items-center gap-4 bg-gray-800 rounded-xl p-4">
                  <div className="w-14 h-14 rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center text-white text-xl font-bold flex-shrink-0">
                    {selected.user.split(" ").map(n => n[0]).join("")}
                  </div>
                  <div className="flex-1">
                    <div className="text-white font-bold text-lg">{selected.user}</div>
                    <div className="text-gray-400 text-sm">{selected.email}</div>
                    <div className="flex items-center gap-3 mt-1">
                      <span className={cn("text-xs font-semibold px-2 py-0.5 rounded-full border", statusStyle[selected.status])}>
                        {statusLabel[selected.status]}
                      </span>
                      <span className={cn("text-xs font-semibold px-2 py-0.5 rounded-full capitalize", riskStyle[selected.riskLevel])}>
                        {selected.riskLevel} risk
                      </span>
                    </div>
                  </div>
                </div>
                {[
                  { label: "Country", value: selected.country },
                  { label: "Date of Birth", value: selected.dob },
                  { label: "Phone", value: selected.phone },
                  { label: "ID Number", value: selected.idNumber },
                  { label: "Address", value: selected.address, span: true },
                ].map(item => (
                  <div key={item.label} className={cn("bg-gray-800 rounded-xl p-3", item.span ? "col-span-2" : "")}>
                    <div className="text-gray-500 text-xs mb-0.5">{item.label}</div>
                    <div className="text-white text-sm font-medium">{item.value}</div>
                  </div>
                ))}
              </div>

              {/* Documents */}
              <div>
                <h4 className="text-white font-semibold mb-3 flex items-center gap-2">
                  <span>📁</span> Submitted Documents
                </h4>
                <div className="space-y-2">
                  {selected.documents.map((doc, idx) => {
                    const key = `${selected.id}-${idx}`;
                    const isVerified = docVerified[key] ?? doc.verified;
                    return (
                      <div key={idx} className={cn("flex items-center gap-3 p-3 rounded-xl border transition-all",
                        isVerified ? "bg-emerald-500/5 border-emerald-500/20" : "bg-gray-800 border-gray-700"
                      )}>
                        <div className="w-10 h-10 rounded-lg bg-gray-700 flex items-center justify-center text-xl flex-shrink-0">
                          <DocIcon type={doc.type} />
                        </div>
                        <div className="flex-1">
                          <div className="text-white text-sm font-medium">{doc.type}</div>
                          <div className="text-gray-500 text-xs font-mono">{doc.url}</div>
                        </div>
                        <div className="flex items-center gap-2">
                          {/* Simulate document preview button */}
                          <button className="px-3 py-1.5 bg-gray-700 hover:bg-gray-600 text-gray-300 text-xs rounded-lg transition-colors">
                            View
                          </button>
                          <button onClick={() => handleDocVerify(selected.id, idx, !isVerified)}
                            className={cn("px-3 py-1.5 text-xs font-semibold rounded-lg transition-all",
                              isVerified
                                ? "bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 border border-emerald-500/30"
                                : "bg-gray-700 text-gray-400 hover:bg-gray-600 hover:text-white"
                            )}>
                            {isVerified ? "✓ Verified" : "Mark Verified"}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Notes */}
              <div>
                <h4 className="text-white font-semibold mb-2 flex items-center gap-2">
                  <span>📝</span> Review Notes
                </h4>
                <textarea
                  value={noteInput}
                  onChange={e => setNoteInput(e.target.value)}
                  placeholder="Add internal notes about this KYC application..."
                  rows={3}
                  className="w-full bg-gray-800 border border-gray-700 focus:border-violet-500 text-white rounded-xl p-3 text-sm outline-none resize-none transition-colors"
                />
              </div>

              {/* Risk Level Override */}
              <div>
                <h4 className="text-white font-semibold mb-2">Risk Assessment</h4>
                <div className="flex gap-2">
                  {(["low", "medium", "high"] as const).map(r => (
                    <button key={r} onClick={() => setApplications(prev => prev.map(a => a.id === selected.id ? { ...a, riskLevel: r } : a))}
                      className={cn("flex-1 py-2 rounded-xl text-xs font-bold capitalize transition-all border",
                        selected.riskLevel === r
                          ? r === "low" ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                            : r === "medium" ? "bg-amber-500/20 text-amber-400 border-amber-500/30"
                              : "bg-red-500/20 text-red-400 border-red-500/30"
                          : "bg-gray-800 text-gray-500 border-gray-700 hover:text-white"
                      )}>
                      {r} Risk
                    </button>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-3 gap-3 pt-2 border-t border-gray-800">
                <button onClick={() => handleAction(selected.id, "under_review")}
                  className="py-3 rounded-xl bg-blue-500/10 hover:bg-blue-500/20 border border-blue-500/20 text-blue-400 text-sm font-bold transition-colors">
                  🔍 Flag for Review
                </button>
                <button onClick={() => handleAction(selected.id, "rejected")}
                  className="py-3 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 text-sm font-bold transition-colors">
                  ❌ Reject
                </button>
                <button onClick={() => handleAction(selected.id, "approved")}
                  className="py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white text-sm font-bold transition-colors shadow-lg shadow-emerald-500/20">
                  ✅ Approve KYC
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
