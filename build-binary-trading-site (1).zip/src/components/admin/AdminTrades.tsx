import { useState, useEffect } from "react";
import { cn } from "@/utils/cn";

interface LiveTrade {
  id: string;
  user: string;
  asset: string;
  direction: "up" | "down";
  amount: number;
  entryPrice: number;
  currentPrice: number;
  timeLeft: number;
  totalTime: number;
  payout: number;
  status: "active" | "won" | "lost";
}

const ASSETS = ["BTC/USD", "ETH/USD", "EUR/USD", "GBP/USD", "XAU/USD", "SPX500"];
const USERS = ["john_doe92", "maria_g", "alex_k99", "linda_h", "trader_x", "ben_w22", "sophie_m", "raj_p", "emma_w", "chris_b"];

function randomTrade(id: string): LiveTrade {
  const entryPrice = 40000 + Math.random() * 30000;
  return {
    id,
    user: USERS[Math.floor(Math.random() * USERS.length)],
    asset: ASSETS[Math.floor(Math.random() * ASSETS.length)],
    direction: Math.random() > 0.5 ? "up" : "down",
    amount: [10, 25, 50, 100, 250][Math.floor(Math.random() * 5)],
    entryPrice,
    currentPrice: entryPrice + (Math.random() - 0.5) * 200,
    timeLeft: Math.floor(Math.random() * 60) + 5,
    totalTime: 60,
    payout: 80,
    status: "active",
  };
}

const INITIAL_TRADES: LiveTrade[] = Array.from({ length: 12 }, (_, i) => randomTrade(`T${String(i).padStart(4, "0")}`));

const HISTORICAL = [
  { id: "H001", user: "maria_g", asset: "BTC/USD", direction: "up", amount: 250, profit: 200, entryPrice: 67120.00, exitPrice: 67450.00, time: "14:32:01", status: "won" },
  { id: "H002", user: "john_doe92", asset: "EUR/USD", direction: "down", amount: 100, profit: -100, entryPrice: 1.0854, exitPrice: 1.0849, time: "14:31:15", status: "won" },
  { id: "H003", user: "alex_k99", asset: "XAU/USD", direction: "up", amount: 50, profit: -50, entryPrice: 2315.20, exitPrice: 2312.80, time: "14:30:42", status: "lost" },
  { id: "H004", user: "linda_h", asset: "ETH/USD", direction: "down", amount: 150, profit: 120, entryPrice: 3812.50, exitPrice: 3798.00, time: "14:29:58", status: "won" },
  { id: "H005", user: "sophie_m", asset: "SPX500", direction: "up", amount: 75, profit: -75, entryPrice: 5241.00, exitPrice: 5239.00, time: "14:28:33", status: "lost" },
  { id: "H006", user: "raj_p", asset: "GBP/USD", direction: "up", amount: 200, profit: 160, entryPrice: 1.2638, exitPrice: 1.2652, time: "14:27:12", status: "won" },
  { id: "H007", user: "trader_x", asset: "BTC/USD", direction: "down", amount: 500, profit: 400, entryPrice: 67560.00, exitPrice: 67230.00, time: "14:26:00", status: "won" },
];

export function AdminTrades() {
  const [liveTrades, setLiveTrades] = useState<LiveTrade[]>(INITIAL_TRADES);
  const [tab, setTab] = useState<"live" | "history">("live");
  const [dirFilter, setDirFilter] = useState("all");

  useEffect(() => {
    const interval = setInterval(() => {
      setLiveTrades(prev => {
        const updated: LiveTrade[] = prev.map(t => {
          const newTimeLeft = t.timeLeft - 1;
          const priceMove = (Math.random() - 0.5) * 80;
          if (newTimeLeft <= 0) {
            const won = t.direction === "up" ? t.currentPrice > t.entryPrice : t.currentPrice < t.entryPrice;
            const status: LiveTrade["status"] = won ? "won" : "lost";
            return { ...t, timeLeft: 0, status };
          }
          return { ...t, timeLeft: newTimeLeft, currentPrice: t.currentPrice + priceMove };
        });
        const active = updated.filter(t => t.status === "active");
        const finished = updated.filter(t => t.status !== "active");
        return [...active, ...(finished.length > 0 ? [randomTrade(`T${Date.now()}`)] : [])];
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const filtered = tab === "live"
    ? liveTrades.filter(t => dirFilter === "all" || t.direction === dirFilter)
    : HISTORICAL;

  const totalActive = liveTrades.filter(t => t.status === "active").length;
  const totalVolume = liveTrades.reduce((s, t) => s + t.amount, 0);
  const callCount = liveTrades.filter(t => t.direction === "up").length;
  const putCount = liveTrades.filter(t => t.direction === "down").length;

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-white font-bold text-xl">Live Trade Monitor</h2>
          <p className="text-gray-400 text-sm">Real-time trade tracking across all assets</p>
        </div>
        <div className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 rounded-xl px-4 py-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span className="text-emerald-400 text-sm font-semibold">{totalActive} Active Trades</span>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: "Active Trades", value: totalActive, color: "text-cyan-400" },
          { label: "Total Volume", value: `$${totalVolume.toLocaleString()}`, color: "text-emerald-400" },
          { label: "CALL Trades", value: callCount, color: "text-emerald-400" },
          { label: "PUT Trades", value: putCount, color: "text-red-400" },
        ].map(s => (
          <div key={s.label} className="bg-gray-900 border border-gray-800 rounded-xl px-4 py-3 text-center">
            <div className={`text-xl font-bold ${s.color}`}>{s.value}</div>
            <div className="text-gray-500 text-xs mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-gray-800">
        {(["live", "history"] as const).map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={cn(
              "px-4 py-2.5 text-sm font-medium capitalize border-b-2 transition-all -mb-px",
              tab === t ? "border-violet-500 text-violet-400" : "border-transparent text-gray-400 hover:text-white"
            )}
          >
            {t === "live" ? "🔴 Live Trades" : "📋 Trade History"}
          </button>
        ))}
        {tab === "live" && (
          <div className="ml-auto flex gap-1 pb-2">
            {["all", "up", "down"].map(d => (
              <button
                key={d}
                onClick={() => setDirFilter(d)}
                className={cn(
                  "px-3 py-1 rounded-lg text-xs font-semibold capitalize transition-all",
                  dirFilter === d ? "bg-violet-600 text-white" : "bg-gray-800 text-gray-400 hover:text-white"
                )}
              >
                {d === "up" ? "▲ CALL" : d === "down" ? "▼ PUT" : "All"}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Table */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          {tab === "live" ? (
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-800">
                  <th className="text-left text-gray-400 font-medium px-4 py-3">User</th>
                  <th className="text-left text-gray-400 font-medium px-4 py-3">Asset</th>
                  <th className="text-center text-gray-400 font-medium px-4 py-3">Direction</th>
                  <th className="text-right text-gray-400 font-medium px-4 py-3">Amount</th>
                  <th className="text-right text-gray-400 font-medium px-4 py-3 hidden md:table-cell">Entry</th>
                  <th className="text-right text-gray-400 font-medium px-4 py-3 hidden md:table-cell">Current</th>
                  <th className="text-right text-gray-400 font-medium px-4 py-3 hidden lg:table-cell">PnL</th>
                  <th className="text-center text-gray-400 font-medium px-4 py-3">Timer</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800">
                {filtered.map((trade) => {
                  if (!("timeLeft" in trade)) return null;
                  const t = trade as LiveTrade;
                  const diff = t.currentPrice - t.entryPrice;
                  const winning = t.direction === "up" ? diff > 0 : diff < 0;
                  const pnl = winning ? t.amount * (t.payout / 100) : -t.amount;
                  const progress = (t.timeLeft / t.totalTime) * 100;
                  return (
                    <tr key={t.id} className="hover:bg-gray-800/40 transition-colors">
                      <td className="px-4 py-3">
                        <div className="text-white font-medium">{t.user}</div>
                        <div className="text-gray-500 text-xs">{t.id}</div>
                      </td>
                      <td className="px-4 py-3 text-gray-300">{t.asset}</td>
                      <td className="px-4 py-3 text-center">
                        <span className={cn("text-xs font-bold px-2 py-1 rounded-full", t.direction === "up" ? "bg-emerald-500/10 text-emerald-400" : "bg-red-500/10 text-red-400")}>
                          {t.direction === "up" ? "▲ CALL" : "▼ PUT"}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right text-white font-semibold">${t.amount}</td>
                      <td className="px-4 py-3 text-right text-gray-400 font-mono text-xs hidden md:table-cell">{t.entryPrice.toFixed(2)}</td>
                      <td className="px-4 py-3 text-right font-mono text-xs hidden md:table-cell">
                        <span className={winning ? "text-emerald-400" : "text-red-400"}>{t.currentPrice.toFixed(2)}</span>
                      </td>
                      <td className={cn("px-4 py-3 text-right font-semibold hidden lg:table-cell", pnl >= 0 ? "text-emerald-400" : "text-red-400")}>
                        {pnl >= 0 ? "+" : ""}${pnl.toFixed(2)}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-col items-center gap-1 min-w-[60px]">
                          <span className="text-white text-xs font-mono font-bold">{t.timeLeft}s</span>
                          <div className="w-full bg-gray-700 rounded-full h-1.5 overflow-hidden">
                            <div className={cn("h-1.5 rounded-full transition-all", winning ? "bg-emerald-500" : "bg-red-500")} style={{ width: `${progress}%` }} />
                          </div>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-800">
                  <th className="text-left text-gray-400 font-medium px-4 py-3">ID</th>
                  <th className="text-left text-gray-400 font-medium px-4 py-3">User</th>
                  <th className="text-left text-gray-400 font-medium px-4 py-3">Asset</th>
                  <th className="text-center text-gray-400 font-medium px-4 py-3">Direction</th>
                  <th className="text-right text-gray-400 font-medium px-4 py-3">Amount</th>
                  <th className="text-right text-gray-400 font-medium px-4 py-3 hidden md:table-cell">Entry</th>
                  <th className="text-right text-gray-400 font-medium px-4 py-3 hidden md:table-cell">Exit</th>
                  <th className="text-right text-gray-400 font-medium px-4 py-3">P&L</th>
                  <th className="text-center text-gray-400 font-medium px-4 py-3 hidden lg:table-cell">Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-800">
                {HISTORICAL.map(t => (
                  <tr key={t.id} className="hover:bg-gray-800/40 transition-colors">
                    <td className="px-4 py-3 text-gray-500 text-xs font-mono">{t.id}</td>
                    <td className="px-4 py-3 text-white font-medium">{t.user}</td>
                    <td className="px-4 py-3 text-gray-300">{t.asset}</td>
                    <td className="px-4 py-3 text-center">
                      <span className={cn("text-xs font-bold px-2 py-1 rounded-full", t.direction === "up" ? "bg-emerald-500/10 text-emerald-400" : "bg-red-500/10 text-red-400")}>
                        {t.direction === "up" ? "▲ CALL" : "▼ PUT"}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right text-white font-semibold">${t.amount}</td>
                    <td className="px-4 py-3 text-right text-gray-400 font-mono text-xs hidden md:table-cell">{t.entryPrice.toFixed(2)}</td>
                    <td className="px-4 py-3 text-right text-gray-400 font-mono text-xs hidden md:table-cell">{t.exitPrice.toFixed(2)}</td>
                    <td className={cn("px-4 py-3 text-right font-bold", t.status === "won" ? "text-emerald-400" : "text-red-400")}>
                      {t.status === "won" ? `+$${t.profit}` : `-$${t.amount}`}
                    </td>
                    <td className="px-4 py-3 text-center text-gray-500 text-xs hidden lg:table-cell">{t.time}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}
