import { useState } from "react";
import { AdminSidebar } from "./AdminSidebar";
import { AdminOverview } from "./AdminOverview";
import { AdminUsers } from "./AdminUsers";
import { AdminTrades } from "./AdminTrades";
import { AdminWithdrawals } from "./AdminWithdrawals";
import { AdminAnalytics } from "./AdminAnalytics";
import { AdminSettings } from "./AdminSettings";
import { AdminKYC } from "./AdminKYC";

export type AdminPage = "overview" | "users" | "trades" | "withdrawals" | "analytics" | "kyc" | "settings";

export function AdminDashboard({ onExit }: { onExit: () => void }) {
  const [activePage, setActivePage] = useState<AdminPage>("overview");
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const renderPage = () => {
    switch (activePage) {
      case "overview":     return <AdminOverview />;
      case "users":        return <AdminUsers />;
      case "trades":       return <AdminTrades />;
      case "withdrawals":  return <AdminWithdrawals />;
      case "analytics":    return <AdminAnalytics />;
      case "kyc":          return <AdminKYC />;
      case "settings":     return <AdminSettings />;
      default:             return <AdminOverview />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-950 flex">
      {/* Sidebar */}
      <AdminSidebar
        activePage={activePage}
        onNavigate={setActivePage}
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
        onExit={onExit}
      />

      {/* Main Content */}
      <div className={`flex-1 flex flex-col transition-all duration-300 ${sidebarOpen ? "ml-64" : "ml-16"}`}>
        {/* Top Bar */}
        <header className="bg-gray-900 border-b border-gray-800 h-16 flex items-center justify-between px-6 sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="text-gray-400 hover:text-white transition-colors p-1"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            <div>
              <h1 className="text-white font-semibold text-lg capitalize">{activePage}</h1>
              <p className="text-gray-500 text-xs">BinaryPro Admin Panel</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {/* Live Indicator */}
            <div className="flex items-center gap-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full px-3 py-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="text-emerald-400 text-xs font-medium">Live</span>
            </div>
            {/* Notifications */}
            <button className="relative text-gray-400 hover:text-white transition-colors p-2 rounded-lg hover:bg-gray-800">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
              </svg>
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            {/* Admin Avatar */}
            <div className="flex items-center gap-2 bg-gray-800 rounded-lg px-3 py-1.5 cursor-pointer hover:bg-gray-700 transition-colors">
              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center text-white text-xs font-bold">A</div>
              <div className="hidden sm:block">
                <div className="text-white text-xs font-medium">Admin</div>
                <div className="text-gray-500 text-xs">Super Admin</div>
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-6 overflow-y-auto">
          {renderPage()}
        </main>
      </div>
    </div>
  );
}
