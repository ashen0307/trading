import { useState, useEffect } from "react";

interface StatCard {
  title: string;
  value: string;
  change: string;
  positive: boolean;
  icon: React.ReactNode;
  color: string;
}

const recentActivity = [
  { user: "john_doe92", action: "Placed CALL trade", asset: "BTC/USD", amount: "$250", time: "2s ago", type: "trade" },
  { user: "maria_g", action: "Withdrawal requested", asset: "Bank Transfer", amount: "$1,500", time: "1m ago", type: "withdrawal" },
  { user: "alex_k99", action: "New registration", asset: "—", amount: "—", time: "3m ago", type: "register" },
  { user: "linda_h", action: "Placed PUT trade", asset: "EUR/USD", amount: "$100", time: "4m ago", type: "trade" },
  { user: "trader_x", action: "Deposit completed", asset: "Crypto", amount: "$5,000", time: "6m ago", type: "deposit" },
  { user: "ben_w22", action: "KYC submitted", asset: "—", amount: "—", time: "8m ago", type: "kyc" },
  { user: "sophie_m", action: "Placed CALL trade", asset: "XAU/USD", amount: "$50", time: "9m ago", type: "trade" },
  { user: "raj_p", action: "Withdrawal approved", asset: "Crypto", amount: "$800", time: "11m ago", type: "withdrawal" },
];

const topTraders = [
  { name: "alex_k99", profit: "+$12,450", trades: 342, winRate: 71, avatar: "AK" },
  { name: "maria_g", profit: "+$9,200", trades: 215, winRate: 68, avatar: "MG" },
  { name: "trader_x", profit: "+$7,880", trades: 180, winRate: 65, avatar: "TX" },
  { name: "john_doe92", profit: "+$6,340", trades: 290, winRate: 62, avatar: "JD" },
  { name: "sophie_m", profit: "+$4,910", trades: 134, winRate: 60, avatar: "SM" },
];

function MiniSparkline({ positive }: { positive: boolean }) {
  const points = Array.from({ length: 12 }, (_, i) => ({
    x: (i / 11) * 100,
    y: 50 + (Math.random() - (positive ? 0.4 : 0.6)) * 40,
  }));
  const path = points.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`).join(" ");
  return (
    <svg viewBox="0 0 100 60" className="w-20 h-10" preserveAspectRatio="none">
      <path d={path} fill="none" stroke={positive ? "#10b981" : "#ef4444"} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function AdminOverview() {
  const [stats, setStats] = useState({
    totalUsers: 24857,
    activeTrades: 142,
    dailyRevenue: 48320,
    totalDeposits: 1240500,
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setStats(prev => ({
        totalUsers: prev.totalUsers + Math.floor(Math.random() * 2),
        activeTrades: Math.floor(130 + Math.random() * 30),
        dailyRevenue: prev.dailyRevenue + Math.floor(Math.random() * 200 - 50),
        totalDeposits: prev.totalDeposits + Math.floor(Math.random() * 1000),
      }));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const statCards: StatCard[] = [
    {
      title: "Total Users",
      value: stats.totalUsers.toLocaleString(),
      change: "+3.2% today",
      positive: true,
      color: "from-violet-500 to-indigo-600",
      icon: (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
        </svg>
      ),
    },
    {
      title: "Active Trades",
      value: stats.activeTrades.toString(),
      change: "Live right now",
      positive: true,
      color: "from-emerald-500 to-teal-600",
      icon: (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
        </svg>
      ),
    },
    {
      title: "Daily Revenue",
      value: `$${stats.dailyRevenue.toLocaleString()}`,
      change: "+12.5% vs yesterday",
      positive: true,
      color: "from-amber-500 to-orange-600",
      icon: (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
    },
    {
      title: "Total Deposits",
      value: `$${(stats.totalDeposits / 1000000).toFixed(2)}M`,
      change: "+8.1% this month",
      positive: true,
      color: "from-cyan-500 to-blue-600",
      icon: (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
        </svg>
      ),
    },
  ];

  const activityTypeStyle: Record<string, string> = {
    trade: "bg-cyan-500/10 text-cyan-400",
    withdrawal: "bg-amber-500/10 text-amber-400",
    register: "bg-violet-500/10 text-violet-400",
    deposit: "bg-emerald-500/10 text-emerald-400",
    kyc: "bg-blue-500/10 text-blue-400",
  };

  const activityTypeLabel: Record<string, string> = {
    trade: "TRADE",
    withdrawal: "WITHDRAW",
    register: "NEW USER",
    deposit: "DEPOSIT",
    kyc: "KYC",
  };

  return (
    <div className="space-y-6">
      {/* Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {statCards.map((card) => (
          <div key={card.title} className="bg-gray-900 border border-gray-800 rounded-2xl p-5 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${card.color} flex items-center justify-center text-white`}>
                {card.icon}
              </div>
              <MiniSparkline positive={card.positive} />
            </div>
            <div>
              <div className="text-gray-400 text-xs font-medium mb-1">{card.title}</div>
              <div className="text-white text-2xl font-bold">{card.value}</div>
              <div className={`text-xs font-medium mt-0.5 ${card.positive ? "text-emerald-400" : "text-red-400"}`}>
                {card.positive ? "↑" : "↓"} {card.change}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Secondary Stats Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: "Pending KYC", value: "18", color: "text-amber-400" },
          { label: "Pending Withdrawals", value: "7", color: "text-red-400" },
          { label: "Platform Win Rate", value: "54%", color: "text-emerald-400" },
          { label: "Avg Trade Size", value: "$87", color: "text-cyan-400" },
        ].map(s => (
          <div key={s.label} className="bg-gray-900 border border-gray-800 rounded-xl px-4 py-3 text-center">
            <div className={`text-xl font-bold ${s.color}`}>{s.value}</div>
            <div className="text-gray-500 text-xs mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Activity + Top Traders */}
      <div className="grid grid-cols-1 xl:grid-cols-[1fr_360px] gap-4">
        {/* Recent Activity */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white font-semibold">Live Activity Feed</h3>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="text-emerald-400 text-xs">Live</span>
            </div>
          </div>
          <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
            {recentActivity.map((item, i) => (
              <div key={i} className="flex items-center gap-3 p-3 bg-gray-800/50 rounded-xl hover:bg-gray-800 transition-colors">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-gray-600 to-gray-700 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                  {item.user.slice(0, 2).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-white text-sm font-medium">{item.user}</span>
                    <span className={`text-xs font-semibold px-1.5 py-0.5 rounded ${activityTypeStyle[item.type]}`}>
                      {activityTypeLabel[item.type]}
                    </span>
                  </div>
                  <div className="text-gray-400 text-xs truncate">{item.action}</div>
                </div>
                <div className="text-right flex-shrink-0">
                  {item.amount !== "—" && <div className="text-white text-sm font-semibold">{item.amount}</div>}
                  <div className="text-gray-500 text-xs">{item.time}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Traders */}
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <h3 className="text-white font-semibold mb-4">Top Traders</h3>
          <div className="space-y-3">
            {topTraders.map((trader, idx) => (
              <div key={trader.name} className="flex items-center gap-3 p-3 bg-gray-800/50 rounded-xl hover:bg-gray-800 transition-colors">
                <div className="text-gray-600 text-sm font-bold w-4 flex-shrink-0">#{idx + 1}</div>
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                  {trader.avatar}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-white text-sm font-medium">{trader.name}</div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <div className="flex-1 bg-gray-700 rounded-full h-1">
                      <div className="bg-emerald-500 h-1 rounded-full" style={{ width: `${trader.winRate}%` }} />
                    </div>
                    <span className="text-gray-400 text-xs">{trader.winRate}%</span>
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="text-emerald-400 text-sm font-bold">{trader.profit}</div>
                  <div className="text-gray-500 text-xs">{trader.trades} trades</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
