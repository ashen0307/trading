import { useState } from "react";
import { cn } from "@/utils/cn";

interface UserDepositProps {
  balance: number;
  onDeposit: (amount: number) => void;
}

const AMOUNTS = [50, 100, 250, 500, 1000, 2500, 5000, 10000];
const METHODS = [
  { id: "card", label: "Credit / Debit Card", icon: "💳", desc: "Visa, Mastercard, Amex", fee: "2.5%", time: "Instant" },
  { id: "bank", label: "Bank Transfer", icon: "🏦", desc: "SEPA, SWIFT, ACH", fee: "Free", time: "1–3 days" },
  { id: "btc", label: "Bitcoin (BTC)", icon: "₿", desc: "BTC network", fee: "0.1%", time: "~30 min" },
  { id: "eth", label: "Ethereum (ETH)", icon: "Ξ", desc: "ERC-20 tokens", fee: "0.1%", time: "~5 min" },
  { id: "usdt", label: "USDT", icon: "💲", desc: "TRC-20 or ERC-20", fee: "Free", time: "~5 min" },
  { id: "skrill", label: "Skrill", icon: "💼", desc: "Skrill wallet", fee: "1.5%", time: "Instant" },
];

export function UserDeposit({ balance, onDeposit }: UserDepositProps) {
  const [selected, setSelected] = useState(500);
  const [custom, setCustom] = useState("");
  const [method, setMethod] = useState("card");
  const [step, setStep] = useState<"form" | "processing" | "success">("form");

  const finalAmount = custom ? parseFloat(custom) : selected;
  const selectedMethod = METHODS.find(m => m.id === method)!;
  const fee = selectedMethod.fee === "Free" ? 0 : finalAmount * (parseFloat(selectedMethod.fee) / 100);
  const totalReceived = finalAmount - fee;

  const handleDeposit = () => {
    if (!finalAmount || finalAmount < 10) return;
    setStep("processing");
    setTimeout(() => {
      setStep("success");
      onDeposit(finalAmount);
    }, 2000);
  };

  if (step === "processing") {
    return (
      <div className="max-w-md mx-auto flex flex-col items-center justify-center py-20 gap-5">
        <div className="w-16 h-16 rounded-full border-4 border-emerald-500/30 border-t-emerald-500 animate-spin"></div>
        <div className="text-white font-semibold text-lg">Processing Deposit...</div>
        <div className="text-gray-400 text-sm">Please wait while we confirm your payment.</div>
      </div>
    );
  }

  if (step === "success") {
    return (
      <div className="max-w-md mx-auto flex flex-col items-center justify-center py-20 gap-5">
        <div className="w-20 h-20 rounded-full bg-emerald-500/20 flex items-center justify-center">
          <svg className="w-10 h-10 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <div className="text-white font-bold text-2xl">Deposit Successful!</div>
        <div className="text-emerald-400 font-semibold text-xl">+${finalAmount.toFixed(2)}</div>
        <div className="text-gray-400 text-sm">New Balance: <span className="text-white font-semibold">${(balance).toFixed(2)}</span></div>
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-4 w-full space-y-2 text-sm">
          <div className="flex justify-between"><span className="text-gray-400">Method</span><span className="text-white">{selectedMethod.icon} {selectedMethod.label}</span></div>
          <div className="flex justify-between"><span className="text-gray-400">Amount</span><span className="text-white">${finalAmount.toFixed(2)}</span></div>
          <div className="flex justify-between"><span className="text-gray-400">Fee</span><span className="text-white">{selectedMethod.fee === "Free" ? "Free" : `$${fee.toFixed(2)}`}</span></div>
          <div className="flex justify-between border-t border-gray-800 pt-2"><span className="text-gray-400">Credited</span><span className="text-emerald-400 font-bold">${totalReceived.toFixed(2)}</span></div>
        </div>
        <button onClick={() => setStep("form")} className="bg-emerald-500 hover:bg-emerald-400 text-white font-semibold px-6 py-2.5 rounded-xl transition-colors">
          Make Another Deposit
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl space-y-5">
      {/* Current Balance */}
      <div className="bg-gradient-to-r from-emerald-600/20 to-cyan-600/20 border border-emerald-500/20 rounded-2xl p-4 flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center text-2xl">💰</div>
        <div>
          <div className="text-gray-400 text-sm">Current Balance</div>
          <div className="text-white text-2xl font-bold">${balance.toFixed(2)}</div>
        </div>
      </div>

      {/* Amount Selection */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <h3 className="text-white font-semibold mb-4">Select Amount</h3>
        <div className="grid grid-cols-4 gap-2 mb-4">
          {AMOUNTS.map(a => (
            <button key={a} onClick={() => { setSelected(a); setCustom(""); }}
              className={cn("py-2.5 rounded-xl text-sm font-semibold transition-all",
                selected === a && !custom ? "bg-emerald-500 text-white shadow-lg shadow-emerald-500/25" : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white"
              )}>
              ${a.toLocaleString()}
            </button>
          ))}
        </div>
        <div className="relative">
          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-semibold">$</span>
          <input
            type="number"
            value={custom}
            onChange={e => setCustom(e.target.value)}
            placeholder="Enter custom amount..."
            min={10}
            className="w-full bg-gray-800 border border-gray-700 focus:border-emerald-500 text-white rounded-xl pl-8 pr-4 py-3 text-sm outline-none transition-colors"
          />
        </div>
        {finalAmount > 0 && finalAmount < 10 && (
          <p className="text-red-400 text-xs mt-2">Minimum deposit is $10</p>
        )}
      </div>

      {/* Payment Method */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <h3 className="text-white font-semibold mb-4">Payment Method</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {METHODS.map(m => (
            <button key={m.id} onClick={() => setMethod(m.id)}
              className={cn("flex items-center gap-3 p-3 rounded-xl border text-left transition-all",
                method === m.id ? "bg-emerald-500/10 border-emerald-500/30" : "bg-gray-800 border-gray-700 hover:border-gray-600"
              )}>
              <span className="text-2xl">{m.icon}</span>
              <div className="flex-1 min-w-0">
                <div className={cn("text-sm font-semibold", method === m.id ? "text-emerald-400" : "text-white")}>{m.label}</div>
                <div className="text-gray-500 text-xs">{m.desc}</div>
              </div>
              <div className="text-right flex-shrink-0">
                <div className="text-xs text-gray-400">{m.fee}</div>
                <div className="text-xs text-gray-500">{m.time}</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Summary & CTA */}
      {finalAmount >= 10 && (
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
          <h3 className="text-white font-semibold mb-3">Deposit Summary</h3>
          <div className="space-y-2 text-sm mb-4">
            <div className="flex justify-between"><span className="text-gray-400">Deposit Amount</span><span className="text-white">${finalAmount.toFixed(2)}</span></div>
            <div className="flex justify-between"><span className="text-gray-400">Processing Fee</span><span className="text-white">{selectedMethod.fee === "Free" ? "Free" : `$${fee.toFixed(2)} (${selectedMethod.fee})`}</span></div>
            <div className="flex justify-between"><span className="text-gray-400">Processing Time</span><span className="text-white">{selectedMethod.time}</span></div>
            <div className="flex justify-between border-t border-gray-800 pt-2 mt-2">
              <span className="text-gray-300 font-medium">You will receive</span>
              <span className="text-emerald-400 font-bold text-base">${totalReceived.toFixed(2)}</span>
            </div>
          </div>
          <button onClick={handleDeposit}
            className="w-full bg-emerald-500 hover:bg-emerald-400 text-white font-bold py-4 rounded-xl transition-all shadow-lg shadow-emerald-500/25 text-base">
            {selectedMethod.icon} Deposit ${finalAmount.toFixed(2)} via {selectedMethod.label}
          </button>
          <p className="text-gray-600 text-xs text-center mt-3">🔒 Secured by 256-bit SSL encryption</p>
        </div>
      )}
    </div>
  );
}
