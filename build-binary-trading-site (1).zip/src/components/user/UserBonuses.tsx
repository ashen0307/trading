import { useState } from "react";
import { cn } from "@/utils/cn";

interface UserBonusesProps {
  balance: number;
}

interface Bonus {
  id: string;
  title: string;
  description: string;
  type: "deposit" | "cashback" | "tournament" | "referral" | "loyalty";
  value: string;
  expires: string;
  status: "active" | "claimed" | "expired" | "available";
  progress?: { current: number; required: number; label: string };
  icon: string;
  color: string;
}

const BONUSES: Bonus[] = [
  {
    id: "B1", title: "Welcome Bonus", description: "Get 50% bonus on your first deposit up to $500.", type: "deposit",
    value: "50% up to $500", expires: "May 15, 2024", status: "active", icon: "🎉",
    color: "from-emerald-500/20 to-cyan-500/20 border-emerald-500/30",
    progress: { current: 250, required: 1000, label: "Wagering Progress" },
  },
  {
    id: "B2", title: "Weekend Cashback", description: "Get 10% cashback on net losses every weekend.", type: "cashback",
    value: "10% Cashback", expires: "Every weekend", status: "available", icon: "💸",
    color: "from-violet-500/20 to-indigo-500/20 border-violet-500/30",
  },
  {
    id: "B3", title: "April Trading Tournament", description: "Trade the most this month to win from the $10,000 prize pool!", type: "tournament",
    value: "$10,000 Pool", expires: "Apr 30, 2024", status: "active", icon: "🏆",
    color: "from-amber-500/20 to-orange-500/20 border-amber-500/30",
    progress: { current: 3, required: 10, label: "Your Rank: #3 of 248" },
  },
  {
    id: "B4", title: "Refer a Friend", description: "Earn $50 for every friend who signs up and deposits $100+.", type: "referral",
    value: "$50 per referral", expires: "No expiry", status: "available", icon: "👥",
    color: "from-pink-500/20 to-rose-500/20 border-pink-500/30",
  },
  {
    id: "B5", title: "VIP Loyalty Reward", description: "Your April loyalty reward has been credited to your account.", type: "loyalty",
    value: "$25 Bonus", expires: "Credited Apr 1", status: "claimed", icon: "⭐",
    color: "from-gray-600/20 to-gray-700/20 border-gray-600/30",
  },
  {
    id: "B6", title: "Bitcoin Deposit Bonus", description: "Get an extra 5% when you deposit using Bitcoin.", type: "deposit",
    value: "5% BTC Bonus", expires: "May 31, 2024", status: "available", icon: "₿",
    color: "from-amber-600/20 to-yellow-500/20 border-amber-500/30",
  },
];

const typeColors: Record<string, string> = {
  deposit: "bg-emerald-500/10 text-emerald-400",
  cashback: "bg-violet-500/10 text-violet-400",
  tournament: "bg-amber-500/10 text-amber-400",
  referral: "bg-pink-500/10 text-pink-400",
  loyalty: "bg-blue-500/10 text-blue-400",
};

export function UserBonuses({ balance }: UserBonusesProps) {
  const [bonuses, setBonuses] = useState<Bonus[]>(BONUSES);
  const [referralCopied, setReferralCopied] = useState(false);
  const [promoCode, setPromoCode] = useState("");
  const [promoResult, setPromoResult] = useState<"" | "success" | "error">("");

  void balance;

  const claimBonus = (id: string) => {
    setBonuses(prev => prev.map(b => b.id === id ? { ...b, status: "claimed" } : b));
  };

  const copyReferral = () => {
    setReferralCopied(true);
    setTimeout(() => setReferralCopied(false), 2000);
  };

  const applyPromo = () => {
    if (promoCode.toUpperCase() === "TRADE25") {
      setPromoResult("success");
    } else {
      setPromoResult("error");
    }
    setTimeout(() => setPromoResult(""), 3000);
  };

  const activeCount = bonuses.filter(b => b.status === "active" || b.status === "available").length;
  const totalValue = "$575";

  return (
    <div className="max-w-3xl space-y-5">
      {/* Overview */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-4 text-center">
          <div className="text-2xl mb-1">🎁</div>
          <div className="text-white text-xl font-bold">{activeCount}</div>
          <div className="text-gray-500 text-xs">Active Bonuses</div>
        </div>
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-4 text-center">
          <div className="text-2xl mb-1">💰</div>
          <div className="text-emerald-400 text-xl font-bold">{totalValue}</div>
          <div className="text-gray-500 text-xs">Total Bonus Value</div>
        </div>
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-4 text-center">
          <div className="text-2xl mb-1">👥</div>
          <div className="text-violet-400 text-xl font-bold">3</div>
          <div className="text-gray-500 text-xs">Referrals</div>
        </div>
      </div>

      {/* Promo Code */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <h3 className="text-white font-semibold mb-3">Redeem Promo Code</h3>
        <div className="flex gap-2">
          <input type="text" value={promoCode} onChange={e => setPromoCode(e.target.value.toUpperCase())}
            placeholder="Enter promo code (try TRADE25)..."
            className="flex-1 bg-gray-800 border border-gray-700 focus:border-violet-500 text-white rounded-xl px-4 py-2.5 text-sm outline-none transition-colors uppercase" />
          <button onClick={applyPromo} className="bg-violet-600 hover:bg-violet-500 text-white font-semibold px-5 rounded-xl text-sm transition-colors">
            Apply
          </button>
        </div>
        {promoResult === "success" && (
          <p className="text-emerald-400 text-sm mt-2">🎉 Promo code applied! $25 bonus credited to your account.</p>
        )}
        {promoResult === "error" && (
          <p className="text-red-400 text-sm mt-2">❌ Invalid or expired promo code.</p>
        )}
      </div>

      {/* Bonus Cards */}
      <div>
        <h3 className="text-white font-semibold mb-3">Your Bonuses</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {bonuses.map(bonus => (
            <div key={bonus.id} className={cn("bg-gradient-to-br border rounded-2xl p-4 flex flex-col gap-3",
              bonus.color,
              bonus.status === "claimed" || bonus.status === "expired" ? "opacity-60" : ""
            )}>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{bonus.icon}</span>
                  <div>
                    <div className="text-white font-semibold text-sm">{bonus.title}</div>
                    <span className={cn("text-xs font-semibold px-1.5 py-0.5 rounded-full capitalize", typeColors[bonus.type])}>
                      {bonus.type}
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-white font-bold text-sm">{bonus.value}</div>
                  <div className="text-gray-500 text-xs">{bonus.expires}</div>
                </div>
              </div>

              <p className="text-gray-400 text-xs leading-relaxed">{bonus.description}</p>

              {bonus.progress && (
                <div>
                  <div className="flex justify-between text-xs text-gray-400 mb-1.5">
                    <span>{bonus.progress.label}</span>
                    <span className="text-white">{bonus.progress.current}/{bonus.progress.required}</span>
                  </div>
                  <div className="bg-black/20 rounded-full h-2">
                    <div className="h-2 rounded-full bg-white/40 transition-all"
                      style={{ width: `${Math.min(100, (bonus.progress.current / bonus.progress.required) * 100)}%` }}></div>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between">
                <span className={cn("text-xs font-semibold px-2 py-0.5 rounded-full",
                  bonus.status === "active" ? "bg-emerald-500/20 text-emerald-400" :
                    bonus.status === "available" ? "bg-amber-500/20 text-amber-400" :
                      bonus.status === "claimed" ? "bg-gray-600/40 text-gray-400" :
                        "bg-red-500/20 text-red-400"
                )}>
                  {bonus.status === "active" ? "✓ Active" : bonus.status === "available" ? "Available" : bonus.status === "claimed" ? "✓ Claimed" : "Expired"}
                </span>

                {bonus.status === "available" && (
                  <button onClick={() => claimBonus(bonus.id)}
                    className="bg-white/20 hover:bg-white/30 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors">
                    Claim Now
                  </button>
                )}
                {bonus.status === "active" && bonus.id === "B3" && (
                  <button className="bg-white/20 hover:bg-white/30 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors">
                    View Leaderboard
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Referral Program */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <div className="flex items-center gap-3 mb-4">
          <span className="text-3xl">👥</span>
          <div>
            <h3 className="text-white font-semibold">Referral Program</h3>
            <p className="text-gray-400 text-sm">Earn $50 for every friend who signs up and deposits</p>
          </div>
        </div>

        <div className="bg-gray-800 rounded-xl p-4 mb-4">
          <div className="text-gray-400 text-xs mb-2">Your Referral Link</div>
          <div className="flex items-center gap-2">
            <code className="flex-1 text-violet-400 text-sm bg-gray-700 px-3 py-2 rounded-lg font-mono truncate">
              https://binarypro.com/ref/JD4821
            </code>
            <button onClick={copyReferral}
              className={cn("px-4 py-2 rounded-lg text-sm font-semibold transition-colors flex-shrink-0",
                referralCopied ? "bg-emerald-500 text-white" : "bg-violet-600 hover:bg-violet-500 text-white"
              )}>
              {referralCopied ? "✓ Copied!" : "Copy"}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="bg-gray-800 rounded-xl p-3">
            <div className="text-white font-bold text-lg">3</div>
            <div className="text-gray-500 text-xs">Friends Referred</div>
          </div>
          <div className="bg-gray-800 rounded-xl p-3">
            <div className="text-emerald-400 font-bold text-lg">$150</div>
            <div className="text-gray-500 text-xs">Earned</div>
          </div>
          <div className="bg-gray-800 rounded-xl p-3">
            <div className="text-amber-400 font-bold text-lg">2</div>
            <div className="text-gray-500 text-xs">Pending</div>
          </div>
        </div>

        <div className="mt-3 flex gap-2">
          <button className="flex-1 flex items-center justify-center gap-2 bg-gray-800 hover:bg-gray-700 text-gray-300 py-2 rounded-xl text-sm transition-colors">
            <span>🐦</span> Share on Twitter
          </button>
          <button className="flex-1 flex items-center justify-center gap-2 bg-gray-800 hover:bg-gray-700 text-gray-300 py-2 rounded-xl text-sm transition-colors">
            <span>📱</span> Share via WhatsApp
          </button>
        </div>
      </div>
    </div>
  );
}
