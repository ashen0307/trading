import { useState } from "react";
import { cn } from "@/utils/cn";

interface Notification {
  id: string;
  type: "trade" | "deposit" | "withdrawal" | "system" | "promo" | "security";
  title: string;
  message: string;
  time: string;
  read: boolean;
}

const INITIAL_NOTIFS: Notification[] = [
  { id: "N1", type: "trade", title: "Trade Won! 🎉", message: "Your CALL trade on BTC/USD expired in profit. You earned +$85.00", time: "2 min ago", read: false },
  { id: "N2", type: "deposit", title: "Deposit Confirmed", message: "Your deposit of $500.00 via Credit Card has been credited to your account.", time: "1h ago", read: false },
  { id: "N3", type: "security", title: "New Login Detected", message: "A new login was detected from New York, USA. If this wasn't you, please secure your account immediately.", time: "3h ago", read: false },
  { id: "N4", type: "promo", title: "50% Deposit Bonus! 🎁", message: "Deposit now and get a 50% bonus on your next deposit up to $500. Offer expires in 24 hours.", time: "5h ago", read: true },
  { id: "N5", type: "trade", title: "Trade Expired — Loss", message: "Your PUT trade on EUR/USD expired at a loss. -$50.00 deducted from your balance.", time: "7h ago", read: true },
  { id: "N6", type: "withdrawal", title: "Withdrawal Processing", message: "Your withdrawal request of $200.00 is being processed and will arrive within 1–3 business days.", time: "1d ago", read: true },
  { id: "N7", type: "system", title: "Platform Maintenance", message: "Scheduled maintenance on April 25 from 02:00–04:00 UTC. Trading will be paused during this period.", time: "2d ago", read: true },
  { id: "N8", type: "promo", title: "Weekend Trading Tournament 🏆", message: "Join our weekend trading tournament with a $10,000 prize pool. Registration closes Friday!", time: "3d ago", read: true },
];

const typeConfig = {
  trade: { icon: "📊", color: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20" },
  deposit: { icon: "💰", color: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" },
  withdrawal: { icon: "🏦", color: "bg-amber-500/10 text-amber-400 border-amber-500/20" },
  system: { icon: "⚙️", color: "bg-gray-500/10 text-gray-400 border-gray-500/20" },
  promo: { icon: "🎁", color: "bg-violet-500/10 text-violet-400 border-violet-500/20" },
  security: { icon: "🔒", color: "bg-red-500/10 text-red-400 border-red-500/20" },
};

export function UserNotifications() {
  const [notifications, setNotifications] = useState<Notification[]>(INITIAL_NOTIFS);
  const [filterType, setFilterType] = useState<"all" | Notification["type"]>("all");
  const [settings, setSettings] = useState({
    tradeAlerts: true,
    depositAlerts: true,
    withdrawalAlerts: true,
    promoAlerts: true,
    securityAlerts: true,
    emailNotifications: true,
    pushNotifications: false,
    smsNotifications: false,
  });

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAllRead = () => setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  const markRead = (id: string) => setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  const deleteNotif = (id: string) => setNotifications(prev => prev.filter(n => n.id !== id));

  const filtered = notifications.filter(n => filterType === "all" || n.type === filterType);

  const toggleSetting = (key: keyof typeof settings) => setSettings(prev => ({ ...prev, [key]: !prev[key] }));

  return (
    <div className="max-w-2xl space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h3 className="text-white font-semibold text-lg">Notifications</h3>
          {unreadCount > 0 && (
            <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">{unreadCount} new</span>
          )}
        </div>
        {unreadCount > 0 && (
          <button onClick={markAllRead} className="text-violet-400 hover:text-violet-300 text-sm transition-colors">
            Mark all as read
          </button>
        )}
      </div>

      {/* Type Filters */}
      <div className="flex flex-wrap gap-2">
        {(["all", "trade", "deposit", "withdrawal", "promo", "security", "system"] as const).map(t => (
          <button key={t} onClick={() => setFilterType(t)}
            className={cn("px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all",
              filterType === t ? "bg-violet-600 text-white" : "bg-gray-800 text-gray-400 hover:text-white"
            )}>
            {t === "all" ? "All" : `${typeConfig[t as keyof typeof typeConfig]?.icon || ""} ${t}`}
          </button>
        ))}
      </div>

      {/* Notification List */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden">
        {filtered.length === 0 ? (
          <div className="py-16 text-center text-gray-600">
            <div className="text-4xl mb-2">🔔</div>
            <p className="text-sm">No notifications</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-800">
            {filtered.map(notif => {
              const config = typeConfig[notif.type];
              return (
                <div key={notif.id} className={cn("flex gap-3 p-4 hover:bg-gray-800/40 transition-colors relative",
                  !notif.read && "bg-violet-500/5"
                )}>
                  {!notif.read && (
                    <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-violet-500 rounded-r"></div>
                  )}
                  <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center text-lg flex-shrink-0 border", config.color)}>
                    {config.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="text-white font-semibold text-sm">{notif.title}</span>
                        {!notif.read && <span className="w-2 h-2 rounded-full bg-violet-500 flex-shrink-0"></span>}
                      </div>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <span className="text-gray-600 text-xs">{notif.time}</span>
                        <button onClick={() => deleteNotif(notif.id)} className="text-gray-700 hover:text-red-400 transition-colors ml-1">
                          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                          </svg>
                        </button>
                      </div>
                    </div>
                    <p className="text-gray-400 text-xs mt-1 leading-relaxed">{notif.message}</p>
                    {!notif.read && (
                      <button onClick={() => markRead(notif.id)} className="text-violet-400 hover:text-violet-300 text-xs mt-1.5 transition-colors">
                        Mark as read
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Notification Preferences */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <h3 className="text-white font-semibold mb-4">Notification Preferences</h3>
        <div className="space-y-1">
          {[
            { key: "tradeAlerts", label: "Trade Results", desc: "Win/loss alerts for your trades", icon: "📊" },
            { key: "depositAlerts", label: "Deposit Confirmations", desc: "When deposits are credited", icon: "💰" },
            { key: "withdrawalAlerts", label: "Withdrawal Updates", desc: "Status updates on withdrawals", icon: "🏦" },
            { key: "promoAlerts", label: "Promotions & Bonuses", desc: "Special offers and tournaments", icon: "🎁" },
            { key: "securityAlerts", label: "Security Alerts", desc: "Login attempts and security events", icon: "🔒" },
          ].map(item => (
            <div key={item.key} className="flex items-center justify-between py-3 border-b border-gray-800 last:border-0">
              <div className="flex items-center gap-3">
                <span className="text-lg">{item.icon}</span>
                <div>
                  <div className="text-white text-sm font-medium">{item.label}</div>
                  <div className="text-gray-500 text-xs">{item.desc}</div>
                </div>
              </div>
              <button onClick={() => toggleSetting(item.key as keyof typeof settings)}
                className={cn("relative w-10 h-5.5 rounded-full transition-colors flex-shrink-0 h-[22px]",
                  settings[item.key as keyof typeof settings] ? "bg-violet-600" : "bg-gray-700"
                )}>
                <span className={cn("absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform",
                  settings[item.key as keyof typeof settings] ? "translate-x-4" : "translate-x-0"
                )} />
              </button>
            </div>
          ))}
        </div>

        <div className="mt-4 pt-4 border-t border-gray-800">
          <p className="text-gray-500 text-xs font-semibold uppercase tracking-wider mb-3">Delivery Method</p>
          {[
            { key: "emailNotifications", label: "Email Notifications" },
            { key: "pushNotifications", label: "Push Notifications" },
            { key: "smsNotifications", label: "SMS Notifications" },
          ].map(item => (
            <div key={item.key} className="flex items-center justify-between py-2">
              <span className="text-white text-sm">{item.label}</span>
              <button onClick={() => toggleSetting(item.key as keyof typeof settings)}
                className={cn("relative w-10 rounded-full transition-colors flex-shrink-0 h-[22px]",
                  settings[item.key as keyof typeof settings] ? "bg-emerald-500" : "bg-gray-700"
                )}>
                <span className={cn("absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform",
                  settings[item.key as keyof typeof settings] ? "translate-x-4" : "translate-x-0"
                )} />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
