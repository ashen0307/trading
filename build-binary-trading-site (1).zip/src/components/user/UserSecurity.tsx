import { useState } from "react";
import { cn } from "@/utils/cn";

export function UserSecurity() {
  const [passwordForm, setPasswordForm] = useState({ current: "", newPass: "", confirm: "" });
  const [twoFAEnabled, setTwoFAEnabled] = useState(false);
  const [showTwoFASetup, setShowTwoFASetup] = useState(false);
  const [twoFACode, setTwoFACode] = useState("");
  const [passwordSaved, setPasswordSaved] = useState(false);
  const [passwordError, setPasswordError] = useState("");
  const [activeSessionsOpen, setActiveSessionsOpen] = useState(false);

  const sessions = [
    { id: "S1", device: "Chrome on Windows", location: "New York, USA 🇺🇸", ip: "192.168.1.1", time: "Active now", current: true },
    { id: "S2", device: "Safari on iPhone", location: "Los Angeles, USA 🇺🇸", ip: "10.0.0.5", time: "2h ago", current: false },
    { id: "S3", device: "Firefox on Mac", location: "London, UK 🇬🇧", ip: "172.16.0.1", time: "1d ago", current: false },
  ];

  const loginHistory = [
    { device: "Chrome / Windows", location: "New York, USA", ip: "192.168.1.1", time: "Today, 09:14 AM", success: true },
    { device: "Mobile App / iOS", location: "New York, USA", ip: "10.0.0.5", time: "Yesterday, 06:32 PM", success: true },
    { device: "Unknown Browser", location: "Moscow, Russia", ip: "87.101.0.1", time: "Apr 20, 11:59 PM", success: false },
    { device: "Chrome / Windows", location: "New York, USA", ip: "192.168.1.1", time: "Apr 19, 08:45 AM", success: true },
  ];

  const handlePasswordChange = () => {
    setPasswordError("");
    if (!passwordForm.current) { setPasswordError("Current password is required"); return; }
    if (passwordForm.newPass.length < 8) { setPasswordError("New password must be at least 8 characters"); return; }
    if (passwordForm.newPass !== passwordForm.confirm) { setPasswordError("Passwords do not match"); return; }
    setPasswordSaved(true);
    setPasswordForm({ current: "", newPass: "", confirm: "" });
    setTimeout(() => setPasswordSaved(false), 3000);
  };

  const handleEnable2FA = () => {
    if (twoFACode.length === 6) {
      setTwoFAEnabled(true);
      setShowTwoFASetup(false);
      setTwoFACode("");
    }
  };

  const strength = (() => {
    const p = passwordForm.newPass;
    if (!p) return null;
    let score = 0;
    if (p.length >= 8) score++;
    if (p.length >= 12) score++;
    if (/[A-Z]/.test(p)) score++;
    if (/[0-9]/.test(p)) score++;
    if (/[^A-Za-z0-9]/.test(p)) score++;
    if (score <= 1) return { label: "Weak", color: "bg-red-500", textColor: "text-red-400", width: "20%" };
    if (score <= 2) return { label: "Fair", color: "bg-amber-500", textColor: "text-amber-400", width: "40%" };
    if (score <= 3) return { label: "Good", color: "bg-yellow-500", textColor: "text-yellow-400", width: "60%" };
    if (score <= 4) return { label: "Strong", color: "bg-emerald-500", textColor: "text-emerald-400", width: "80%" };
    return { label: "Very Strong", color: "bg-emerald-400", textColor: "text-emerald-400", width: "100%" };
  })();

  return (
    <div className="max-w-2xl space-y-5">
      {/* Security Score */}
      <div className="bg-gradient-to-r from-violet-600/20 to-indigo-600/20 border border-violet-500/20 rounded-2xl p-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-white font-semibold">Security Score</h3>
          <span className={cn("text-lg font-bold", twoFAEnabled ? "text-emerald-400" : "text-amber-400")}>
            {twoFAEnabled ? "90/100 🛡️" : "65/100 ⚠️"}
          </span>
        </div>
        <div className="bg-gray-800 rounded-full h-2.5 mb-3">
          <div className={cn("h-2.5 rounded-full transition-all", twoFAEnabled ? "bg-emerald-500" : "bg-amber-500")}
            style={{ width: twoFAEnabled ? "90%" : "65%" }}></div>
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs">
          {[
            { label: "Strong Password", done: true },
            { label: "Email Verified", done: true },
            { label: "2FA Enabled", done: twoFAEnabled },
            { label: "KYC Verified", done: true },
          ].map(item => (
            <div key={item.label} className={cn("flex items-center gap-1.5", item.done ? "text-emerald-400" : "text-gray-500")}>
              <span>{item.done ? "✅" : "⭕"}</span>
              <span>{item.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* 2FA */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-white font-semibold">Two-Factor Authentication (2FA)</h3>
            <p className="text-gray-500 text-xs mt-0.5">Add an extra layer of security to your account</p>
          </div>
          <span className={cn("text-xs font-bold px-2 py-1 rounded-full",
            twoFAEnabled ? "bg-emerald-500/10 text-emerald-400" : "bg-gray-700 text-gray-400"
          )}>
            {twoFAEnabled ? "✓ Enabled" : "Disabled"}
          </span>
        </div>

        {twoFAEnabled ? (
          <div className="flex items-center gap-4 p-4 bg-emerald-500/5 border border-emerald-500/20 rounded-xl">
            <span className="text-3xl">🛡️</span>
            <div className="flex-1">
              <div className="text-emerald-400 font-semibold">2FA is Active</div>
              <div className="text-gray-400 text-sm">Your account is protected with Google Authenticator.</div>
            </div>
            <button onClick={() => setTwoFAEnabled(false)} className="text-red-400 hover:text-red-300 text-sm font-semibold transition-colors">
              Disable
            </button>
          </div>
        ) : showTwoFASetup ? (
          <div className="space-y-4">
            <div className="flex items-start gap-4 p-4 bg-gray-800 rounded-xl">
              <div className="w-24 h-24 bg-white rounded-xl flex items-center justify-center flex-shrink-0">
                <div className="text-center">
                  <div className="text-xs font-mono text-gray-800 text-[8px] leading-tight">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <div key={i} className="flex gap-0.5">
                        {Array.from({ length: 5 }).map((_, j) => (
                          <div key={j} className={cn("w-3 h-3", (i + j) % 3 === 0 ? "bg-gray-900" : "bg-transparent")}></div>
                        ))}
                      </div>
                    ))}
                  </div>
                  <div className="text-xs text-gray-600 mt-1">QR Code</div>
                </div>
              </div>
              <div className="flex-1">
                <p className="text-white text-sm font-semibold mb-1">Step 1: Scan QR Code</p>
                <p className="text-gray-400 text-xs mb-2">Open Google Authenticator and scan the QR code, or enter this key manually:</p>
                <code className="text-violet-400 text-xs bg-gray-700 px-2 py-1 rounded font-mono">JBSWY3DPEHPK3PXP</code>
              </div>
            </div>
            <div>
              <p className="text-white text-sm font-semibold mb-2">Step 2: Enter the 6-digit code</p>
              <input type="text" value={twoFACode} onChange={e => setTwoFACode(e.target.value.slice(0, 6))}
                placeholder="000000" maxLength={6}
                className="w-full bg-gray-800 border border-gray-700 focus:border-violet-500 text-white rounded-xl px-4 py-3 text-center text-2xl font-mono tracking-widest outline-none transition-colors" />
            </div>
            <div className="flex gap-3">
              <button onClick={() => setShowTwoFASetup(false)} className="flex-1 bg-gray-800 hover:bg-gray-700 text-gray-300 font-semibold py-2.5 rounded-xl transition-colors">
                Cancel
              </button>
              <button onClick={handleEnable2FA} disabled={twoFACode.length !== 6}
                className="flex-1 bg-violet-600 hover:bg-violet-500 disabled:opacity-50 text-white font-bold py-2.5 rounded-xl transition-colors">
                Verify & Enable
              </button>
            </div>
          </div>
        ) : (
          <button onClick={() => setShowTwoFASetup(true)}
            className="w-full flex items-center gap-3 p-4 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-xl transition-colors text-left">
            <span className="text-2xl">📱</span>
            <div>
              <div className="text-white font-semibold text-sm">Enable Google Authenticator</div>
              <div className="text-gray-400 text-xs">Scan a QR code with your phone</div>
            </div>
            <svg className="w-4 h-4 text-gray-500 ml-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
            </svg>
          </button>
        )}
      </div>

      {/* Password */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <h3 className="text-white font-semibold mb-4">Change Password</h3>
        <div className="space-y-3">
          {[
            { key: "current", label: "Current Password", placeholder: "Enter current password" },
            { key: "newPass", label: "New Password", placeholder: "At least 8 characters" },
            { key: "confirm", label: "Confirm New Password", placeholder: "Re-enter new password" },
          ].map(f => (
            <div key={f.key}>
              <label className="text-gray-400 text-xs font-medium block mb-1.5">{f.label}</label>
              <input type="password"
                value={passwordForm[f.key as keyof typeof passwordForm]}
                onChange={e => setPasswordForm(prev => ({ ...prev, [f.key]: e.target.value }))}
                placeholder={f.placeholder}
                className="w-full bg-gray-800 border border-gray-700 focus:border-violet-500 text-white rounded-xl px-4 py-2.5 text-sm outline-none transition-colors" />
            </div>
          ))}

          {/* Strength Meter */}
          {strength && (
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-gray-500">Password Strength</span>
                <span className={strength.textColor}>{strength.label}</span>
              </div>
              <div className="bg-gray-700 rounded-full h-1.5">
                <div className={cn("h-1.5 rounded-full transition-all", strength.color)} style={{ width: strength.width }}></div>
              </div>
            </div>
          )}

          {passwordError && <p className="text-red-400 text-xs">⚠️ {passwordError}</p>}
          {passwordSaved && <p className="text-emerald-400 text-xs">✅ Password updated successfully!</p>}

          <button onClick={handlePasswordChange}
            className="w-full bg-violet-600 hover:bg-violet-500 text-white font-semibold py-2.5 rounded-xl transition-colors mt-2">
            Update Password
          </button>
        </div>
      </div>

      {/* Active Sessions */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-white font-semibold">Active Sessions</h3>
          <button onClick={() => setActiveSessionsOpen(!activeSessionsOpen)} className="text-gray-400 hover:text-white text-sm transition-colors">
            {activeSessionsOpen ? "Hide" : "Show all"}
          </button>
        </div>
        <div className="space-y-2">
          {(activeSessionsOpen ? sessions : sessions.slice(0, 1)).map(s => (
            <div key={s.id} className={cn("flex items-center gap-3 p-3 rounded-xl border",
              s.current ? "bg-emerald-500/5 border-emerald-500/20" : "bg-gray-800 border-gray-700"
            )}>
              <span className="text-2xl">{s.device.includes("iPhone") || s.device.includes("Mobile") ? "📱" : "💻"}</span>
              <div className="flex-1">
                <div className="text-white text-sm font-medium">{s.device}</div>
                <div className="text-gray-500 text-xs">{s.location} · {s.ip}</div>
              </div>
              <div className="text-right">
                <div className={cn("text-xs font-semibold", s.current ? "text-emerald-400" : "text-gray-400")}>{s.time}</div>
                {!s.current && (
                  <button className="text-red-400 hover:text-red-300 text-xs mt-0.5 transition-colors">Revoke</button>
                )}
                {s.current && <div className="text-emerald-600 text-xs">This device</div>}
              </div>
            </div>
          ))}
        </div>
        {!activeSessionsOpen && sessions.length > 1 && (
          <button onClick={() => setActiveSessionsOpen(true)} className="w-full mt-2 text-gray-500 hover:text-gray-300 text-xs py-2 transition-colors">
            + {sessions.length - 1} more session(s)
          </button>
        )}
      </div>

      {/* Login History */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <h3 className="text-white font-semibold mb-4">Login History</h3>
        <div className="space-y-2">
          {loginHistory.map((log, i) => (
            <div key={i} className={cn("flex items-center gap-3 p-3 rounded-xl", log.success ? "bg-gray-800" : "bg-red-500/5 border border-red-500/20")}>
              <span className={cn("text-xl", log.success ? "" : "text-red-400")}>{log.success ? "✅" : "🚨"}</span>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-white text-sm font-medium">{log.device}</span>
                  {!log.success && <span className="text-red-400 text-xs font-semibold bg-red-500/10 px-1.5 py-0.5 rounded">FAILED</span>}
                </div>
                <div className="text-gray-500 text-xs">{log.location} · {log.ip}</div>
              </div>
              <div className="text-gray-500 text-xs">{log.time}</div>
            </div>
          ))}
        </div>
        {loginHistory.some(l => !l.success) && (
          <div className="mt-3 p-3 bg-red-500/10 border border-red-500/20 rounded-xl">
            <p className="text-red-400 text-xs">🚨 Suspicious login attempt detected. If this wasn't you, change your password immediately and enable 2FA.</p>
          </div>
        )}
      </div>
    </div>
  );
}
