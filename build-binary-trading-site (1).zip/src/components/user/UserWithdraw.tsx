import { useState } from "react";
import { cn } from "@/utils/cn";

interface UserWithdrawProps {
  balance: number;
  onWithdraw: (amount: number) => void;
}

const METHODS = [
  { id: "bank", label: "Bank Transfer", icon: "🏦", desc: "1–3 business days", fee: "Free", min: 20 },
  { id: "btc", label: "Bitcoin (BTC)", icon: "₿", desc: "~30–60 minutes", fee: "0.1%", min: 50 },
  { id: "eth", label: "Ethereum (ETH)", icon: "Ξ", desc: "~5–10 minutes", fee: "0.1%", min: 30 },
  { id: "usdt", label: "USDT (TRC-20)", icon: "💲", desc: "~5 minutes", fee: "Free", min: 20 },
];

const PRESETS = [50, 100, 200, 500, 1000];

export function UserWithdraw({ balance, onWithdraw }: UserWithdrawProps) {
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("bank");
  const [accountInfo, setAccountInfo] = useState("");
  const [step, setStep] = useState<"form" | "confirm" | "processing" | "success">("form");
  const [errors, setErrors] = useState<string[]>([]);

  const selectedMethod = METHODS.find(m => m.id === method)!;
  const numAmount = parseFloat(amount) || 0;
  const fee = selectedMethod.fee === "Free" ? 0 : numAmount * (parseFloat(selectedMethod.fee) / 100);
  const youGet = numAmount - fee;

  const recentWithdrawals = [
    { id: "W-4421", amount: 500, method: "Bank Transfer", status: "completed", date: "Apr 20, 2024" },
    { id: "W-4415", amount: 200, method: "USDT", status: "completed", date: "Apr 15, 2024" },
    { id: "W-4398", amount: 1000, method: "Bitcoin", status: "processing", date: "Apr 10, 2024" },
  ];

  const validate = () => {
    const errs: string[] = [];
    if (!numAmount || numAmount < selectedMethod.min) errs.push(`Minimum withdrawal is $${selectedMethod.min}`);
    if (numAmount > balance) errs.push("Insufficient balance");
    if (!accountInfo.trim()) errs.push("Please enter your account/wallet details");
    setErrors(errs);
    return errs.length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    setStep("confirm");
  };

  const handleConfirm = () => {
    setStep("processing");
    setTimeout(() => {
      setStep("success");
      onWithdraw(numAmount);
    }, 2500);
  };

  if (step === "processing") {
    return (
      <div className="max-w-md mx-auto flex flex-col items-center justify-center py-20 gap-5">
        <div className="w-16 h-16 rounded-full border-4 border-amber-500/30 border-t-amber-500 animate-spin"></div>
        <div className="text-white font-semibold text-lg">Submitting Request...</div>
        <div className="text-gray-400 text-sm">Your withdrawal is being processed.</div>
      </div>
    );
  }

  if (step === "success") {
    return (
      <div className="max-w-md mx-auto flex flex-col items-center justify-center py-16 gap-5">
        <div className="w-20 h-20 rounded-full bg-emerald-500/20 flex items-center justify-center">
          <svg className="w-10 h-10 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <div className="text-white font-bold text-2xl">Request Submitted!</div>
        <div className="text-amber-400 font-semibold">Pending Review</div>
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-4 w-full space-y-2 text-sm">
          <div className="flex justify-between"><span className="text-gray-400">Amount</span><span className="text-white">${numAmount.toFixed(2)}</span></div>
          <div className="flex justify-between"><span className="text-gray-400">Method</span><span className="text-white">{selectedMethod.icon} {selectedMethod.label}</span></div>
          <div className="flex justify-between"><span className="text-gray-400">You Receive</span><span className="text-emerald-400 font-bold">${youGet.toFixed(2)}</span></div>
          <div className="flex justify-between"><span className="text-gray-400">ETA</span><span className="text-white">{selectedMethod.desc}</span></div>
          <div className="flex justify-between border-t border-gray-800 pt-2"><span className="text-gray-400">New Balance</span><span className="text-white font-semibold">${(balance - numAmount).toFixed(2)}</span></div>
        </div>
        <p className="text-gray-500 text-xs text-center">Withdrawals are typically processed within 24 hours. You'll receive an email confirmation shortly.</p>
        <button onClick={() => { setStep("form"); setAmount(""); setAccountInfo(""); }} className="bg-emerald-500 hover:bg-emerald-400 text-white font-semibold px-6 py-2.5 rounded-xl transition-colors">
          New Withdrawal
        </button>
      </div>
    );
  }

  if (step === "confirm") {
    return (
      <div className="max-w-md mx-auto py-8">
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-6 space-y-4">
          <h3 className="text-white font-bold text-lg text-center">Confirm Withdrawal</h3>
          <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-3 text-amber-400 text-sm text-center">
            ⚠️ This action cannot be undone once confirmed
          </div>
          <div className="space-y-3 text-sm">
            {[
              { label: "Amount", value: `$${numAmount.toFixed(2)}` },
              { label: "Method", value: `${selectedMethod.icon} ${selectedMethod.label}` },
              { label: "Account", value: accountInfo },
              { label: "Fee", value: selectedMethod.fee === "Free" ? "Free" : `$${fee.toFixed(2)}` },
              { label: "You Receive", value: `$${youGet.toFixed(2)}` },
              { label: "Processing Time", value: selectedMethod.desc },
            ].map(item => (
              <div key={item.label} className="flex justify-between py-2 border-b border-gray-800 last:border-0">
                <span className="text-gray-400">{item.label}</span>
                <span className="text-white font-medium text-right max-w-[180px] truncate">{item.value}</span>
              </div>
            ))}
          </div>
          <div className="flex gap-3 pt-2">
            <button onClick={() => setStep("form")} className="flex-1 bg-gray-800 hover:bg-gray-700 text-gray-300 font-semibold py-3 rounded-xl transition-colors">
              Back
            </button>
            <button onClick={handleConfirm} className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-white font-bold py-3 rounded-xl transition-colors">
              Confirm Withdrawal
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl space-y-5">
      {/* Balance */}
      <div className="bg-gradient-to-r from-amber-600/20 to-orange-600/20 border border-amber-500/20 rounded-2xl p-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-amber-500/20 flex items-center justify-center text-2xl">🏦</div>
          <div>
            <div className="text-gray-400 text-sm">Available Balance</div>
            <div className="text-white text-2xl font-bold">${balance.toFixed(2)}</div>
          </div>
        </div>
        <div className="text-right">
          <div className="text-gray-500 text-xs">Max withdrawal</div>
          <div className="text-amber-400 font-semibold">${Math.min(balance, 10000).toFixed(2)}</div>
        </div>
      </div>

      {/* Method Selection */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <h3 className="text-white font-semibold mb-4">Withdrawal Method</h3>
        <div className="grid grid-cols-2 gap-2">
          {METHODS.map(m => (
            <button key={m.id} onClick={() => setMethod(m.id)}
              className={cn("flex items-center gap-3 p-3 rounded-xl border text-left transition-all",
                method === m.id ? "bg-amber-500/10 border-amber-500/30" : "bg-gray-800 border-gray-700 hover:border-gray-600"
              )}>
              <span className="text-2xl">{m.icon}</span>
              <div>
                <div className={cn("text-sm font-semibold", method === m.id ? "text-amber-400" : "text-white")}>{m.label}</div>
                <div className="text-gray-500 text-xs">{m.desc} · {m.fee}</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Amount */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <h3 className="text-white font-semibold mb-4">Withdrawal Amount</h3>
        <div className="flex flex-wrap gap-2 mb-4">
          {PRESETS.filter(p => p <= balance).map(p => (
            <button key={p} onClick={() => setAmount(p.toString())}
              className={cn("px-3 py-1.5 rounded-lg text-sm font-semibold transition-all",
                amount === p.toString() ? "bg-amber-500 text-white" : "bg-gray-800 text-gray-400 hover:text-white"
              )}>
              ${p}
            </button>
          ))}
          <button onClick={() => setAmount(Math.min(balance, 10000).toFixed(2))}
            className="px-3 py-1.5 rounded-lg text-sm font-semibold bg-gray-800 text-gray-400 hover:text-white transition-all">
            Max
          </button>
        </div>
        <div className="relative">
          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-semibold">$</span>
          <input type="number" value={amount} onChange={e => setAmount(e.target.value)}
            placeholder={`Min $${selectedMethod.min}`}
            className="w-full bg-gray-800 border border-gray-700 focus:border-amber-500 text-white rounded-xl pl-8 pr-4 py-3 text-sm outline-none transition-colors" />
        </div>
        {numAmount > 0 && (
          <div className="mt-3 flex justify-between text-sm bg-gray-800 rounded-xl px-4 py-3">
            <span className="text-gray-400">You will receive</span>
            <span className="text-emerald-400 font-bold">${youGet.toFixed(2)}</span>
          </div>
        )}
      </div>

      {/* Account Info */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <h3 className="text-white font-semibold mb-4">
          {method === "bank" ? "Bank Account Details" : "Wallet Address"}
        </h3>
        <textarea
          value={accountInfo}
          onChange={e => setAccountInfo(e.target.value)}
          placeholder={method === "bank" ? "Bank name, Account number, Routing/IBAN/SWIFT..." : "Enter your wallet address..."}
          rows={3}
          className="w-full bg-gray-800 border border-gray-700 focus:border-amber-500 text-white rounded-xl p-3 text-sm outline-none resize-none transition-colors"
        />
      </div>

      {/* Errors */}
      {errors.length > 0 && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 space-y-1">
          {errors.map((e, i) => <p key={i} className="text-red-400 text-sm">• {e}</p>)}
        </div>
      )}

      <button onClick={handleSubmit}
        className="w-full bg-amber-500 hover:bg-amber-400 text-white font-bold py-4 rounded-xl transition-all shadow-lg shadow-amber-500/20 text-base">
        Request Withdrawal of ${numAmount > 0 ? numAmount.toFixed(2) : "0.00"}
      </button>

      {/* Recent Withdrawals */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <h3 className="text-white font-semibold mb-3">Recent Withdrawals</h3>
        <div className="space-y-2">
          {recentWithdrawals.map(w => (
            <div key={w.id} className="flex items-center justify-between p-3 bg-gray-800 rounded-xl text-sm">
              <div>
                <div className="text-white font-medium">{w.method}</div>
                <div className="text-gray-500 text-xs">{w.date} · {w.id}</div>
              </div>
              <div className="text-right">
                <div className="text-white font-semibold">${w.amount}</div>
                <div className={cn("text-xs font-medium", w.status === "completed" ? "text-emerald-400" : "text-amber-400")}>
                  {w.status === "completed" ? "✅ Completed" : "⏳ Processing"}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
