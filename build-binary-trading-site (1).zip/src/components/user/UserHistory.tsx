import { useState } from "react";
import { cn } from "@/utils/cn";
import type { TradeRecord } from "../TradeHistory";

interface UserHistoryProps {
  trades: TradeRecord[];
}

export function UserHistory({ trades }: UserHistoryProps) {
  const [filter, setFilter] = useState<"all" | "won" | "lost">("all");
  const [assetFilter, setAssetFilter] = useState("all");
  const [sortBy, setSortBy] = useState<"time" | "amount" | "profit">("time");

  const assets = ["all", ...Array.from(new Set(trades.map(t => t.asset)))];

  const filtered = [...trades]
    .filter(t => filter === "all" || (filter === "won" ? t.won : !t.won))
    .filter(t => assetFilter === "all" || t.asset === assetFilter)
    .sort((a, b) => {
      if (sortBy === "amount") return b.amount - a.amount;
      if (sortBy === "profit") return (b.won ? b.profit : -b.amount) - (a.won ? a.profit : -a.amount);
      return 0;
    })
    .reverse();

  const totalProfit = trades.reduce((s, t) => s + (t.won ? t.profit : -t.amount), 0);
  const winRate = trades.length > 0 ? Math.round((trades.filter(t => t.won).length / trades.length) * 100) : 0;
  const totalVolume = trades.reduce((s, t) => s + t.amount, 0);
  const bestTrade = trades.reduce<TradeRecord | null>((best, t) => {
    const p = t.won ? t.profit : -t.amount;
    if (!best) return t;
    const bp = best.won ? best.profit : -best.amount;
    return p > bp ? t : best;
  }, null);

  if (trades.length === 0) {
    return (
      <div className="max-w-2xl">
        <div className="bg-gray-900 border border-gray-800 rounded-2xl p-16 text-center">
          <div className="text-5xl mb-4">📊</div>
          <div className="text-white font-semibold text-lg mb-2">No Trades Yet</div>
          <p className="text-gray-500 text-sm">Your trade history will appear here once you start trading.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl space-y-5">
      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: "Total Trades", value: trades.length, color: "text-white", icon: "📊" },
          { label: "Win Rate", value: `${winRate}%`, color: winRate >= 50 ? "text-emerald-400" : "text-red-400", icon: "🎯" },
          { label: "Total P&L", value: `${totalProfit >= 0 ? "+" : ""}$${totalProfit.toFixed(2)}`, color: totalProfit >= 0 ? "text-emerald-400" : "text-red-400", icon: "💰" },
          { label: "Volume Traded", value: `$${totalVolume.toFixed(0)}`, color: "text-cyan-400", icon: "📈" },
        ].map(s => (
          <div key={s.label} className="bg-gray-900 border border-gray-800 rounded-xl p-3 text-center">
            <div className="text-xl mb-1">{s.icon}</div>
            <div className={`text-lg font-bold ${s.color}`}>{s.value}</div>
            <div className="text-gray-500 text-xs">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Best Trade */}
      {bestTrade && (
        <div className="bg-gradient-to-r from-emerald-600/10 to-cyan-600/10 border border-emerald-500/20 rounded-2xl p-4 flex items-center gap-4">
          <span className="text-3xl">🏆</span>
          <div>
            <div className="text-gray-400 text-xs font-medium">Best Trade</div>
            <div className="text-white font-bold">{bestTrade.asset} — {bestTrade.direction === "up" ? "▲ CALL" : "▼ PUT"}</div>
            <div className="text-emerald-400 font-semibold">{bestTrade.won ? `+$${bestTrade.profit.toFixed(2)}` : `-$${bestTrade.amount.toFixed(2)}`}</div>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-wrap gap-2 items-center">
        <div className="flex gap-1.5">
          {(["all", "won", "lost"] as const).map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={cn("px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all",
                filter === f ? "bg-violet-600 text-white" : "bg-gray-800 text-gray-400 hover:text-white"
              )}>
              {f === "all" ? "All" : f === "won" ? "✅ Won" : "❌ Lost"}
            </button>
          ))}
        </div>
        {assets.length > 1 && (
          <select value={assetFilter} onChange={e => setAssetFilter(e.target.value)}
            className="bg-gray-800 border border-gray-700 text-gray-300 text-xs rounded-lg px-3 py-1.5 outline-none">
            {assets.map(a => <option key={a} value={a}>{a === "all" ? "All Assets" : a}</option>)}
          </select>
        )}
        <select value={sortBy} onChange={e => setSortBy(e.target.value as "time" | "amount" | "profit")}
          className="bg-gray-800 border border-gray-700 text-gray-300 text-xs rounded-lg px-3 py-1.5 outline-none">
          <option value="time">Sort: Latest</option>
          <option value="amount">Sort: Amount</option>
          <option value="profit">Sort: P&L</option>
        </select>
        <span className="text-gray-600 text-xs ml-auto">{filtered.length} trades</span>
      </div>

      {/* Trade List */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden">
        <div className="divide-y divide-gray-800 max-h-[600px] overflow-y-auto">
          {filtered.map(trade => {
            const pnl = trade.won ? trade.profit : -trade.amount;
            return (
              <div key={trade.id} className={cn("flex items-center gap-3 px-4 py-3 hover:bg-gray-800/50 transition-colors",
                trade.won ? "border-l-2 border-emerald-500" : "border-l-2 border-red-500"
              )}>
                <div className={cn("w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0",
                  trade.direction === "up" ? "bg-emerald-500" : "bg-red-500"
                )}>
                  {trade.direction === "up" ? "▲" : "▼"}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-white font-semibold text-sm">{trade.asset}</span>
                    <span className={cn("text-xs font-medium", trade.direction === "up" ? "text-emerald-400" : "text-red-400")}>
                      {trade.direction === "up" ? "CALL" : "PUT"}
                    </span>
                    <span className={cn("text-xs font-semibold px-1.5 py-0.5 rounded-full",
                      trade.won ? "bg-emerald-500/10 text-emerald-400" : "bg-red-500/10 text-red-400"
                    )}>
                      {trade.won ? "WIN" : "LOSS"}
                    </span>
                  </div>
                  <div className="text-gray-500 text-xs mt-0.5">
                    {trade.time} · {trade.entryPrice.toFixed(2)} → {trade.exitPrice.toFixed(2)}
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className={cn("font-bold text-sm", pnl >= 0 ? "text-emerald-400" : "text-red-400")}>
                    {pnl >= 0 ? "+" : ""}${Math.abs(pnl).toFixed(2)}
                  </div>
                  <div className="text-gray-600 text-xs">${trade.amount} invested</div>
                </div>
              </div>
            );
          })}
          {filtered.length === 0 && (
            <div className="py-12 text-center text-gray-600">
              <p className="text-sm">No trades match your filters</p>
            </div>
          )}
        </div>
      </div>

      {/* Export Button */}
      <button className="flex items-center gap-2 text-gray-400 hover:text-white text-sm transition-colors border border-gray-800 hover:border-gray-700 rounded-xl px-4 py-2.5">
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
        </svg>
        Export Trade History (CSV)
      </button>
    </div>
  );
}
