import { cn } from "@/utils/cn";
import type { TradeRecord } from "../TradeHistory";

interface UserProfileProps {
  balance: number;
  trades: TradeRecord[];
}

export function UserProfile({ balance, trades }: UserProfileProps) {
  const wins = trades.filter(t => t.won).length;
  const losses = trades.filter(t => !t.won).length;
  const winRate = trades.length > 0 ? Math.round((wins / trades.length) * 100) : 0;
  const totalProfit = trades.reduce((s, t) => s + (t.won ? t.profit : -t.amount), 0);
  const totalVolume = trades.reduce((s, t) => s + t.amount, 0);

  const stats = [
    { label: "Account Balance", value: `$${balance.toFixed(2)}`, color: "text-emerald-400", icon: "💰" },
    { label: "Total Trades", value: trades.length.toString(), color: "text-cyan-400", icon: "📊" },
    { label: "Win Rate", value: `${winRate}%`, color: winRate >= 50 ? "text-emerald-400" : "text-red-400", icon: "🎯" },
    { label: "Total P&L", value: `${totalProfit >= 0 ? "+" : ""}$${totalProfit.toFixed(2)}`, color: totalProfit >= 0 ? "text-emerald-400" : "text-red-400", icon: "📈" },
    { label: "Total Volume", value: `$${totalVolume.toFixed(2)}`, color: "text-violet-400", icon: "💹" },
    { label: "Wins / Losses", value: `${wins} / ${losses}`, color: "text-amber-400", icon: "🏆" },
  ];

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Profile Card */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl overflow-hidden">
        <div className="h-24 bg-gradient-to-r from-emerald-600/30 via-cyan-600/30 to-violet-600/30"></div>
        <div className="px-6 pb-6">
          <div className="flex items-end gap-4 -mt-10 mb-4">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-emerald-400 to-cyan-500 flex items-center justify-center text-white text-2xl font-bold border-4 border-gray-900 flex-shrink-0">
              JD
            </div>
            <div className="pb-1">
              <div className="text-white font-bold text-xl">John Doe</div>
              <div className="text-gray-400 text-sm">john.doe@email.com</div>
            </div>
            <div className="ml-auto pb-1">
              <span className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold px-3 py-1 rounded-full">
                ✅ KYC Verified
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-4">
            <div className="bg-gray-800 rounded-xl p-3">
              <div className="text-gray-500 text-xs">Member Since</div>
              <div className="text-white font-semibold text-sm mt-0.5">Jan 12, 2024</div>
            </div>
            <div className="bg-gray-800 rounded-xl p-3">
              <div className="text-gray-500 text-xs">Account ID</div>
              <div className="text-white font-semibold text-sm mt-0.5 font-mono">U001234</div>
            </div>
            <div className="bg-gray-800 rounded-xl p-3">
              <div className="text-gray-500 text-xs">Account Tier</div>
              <div className="text-amber-400 font-semibold text-sm mt-0.5">⭐ Gold</div>
            </div>
            <div className="bg-gray-800 rounded-xl p-3">
              <div className="text-gray-500 text-xs">Country</div>
              <div className="text-white font-semibold text-sm mt-0.5">🇺🇸 United States</div>
            </div>
            <div className="bg-gray-800 rounded-xl p-3">
              <div className="text-gray-500 text-xs">Phone</div>
              <div className="text-white font-semibold text-sm mt-0.5">+1 555-0123</div>
            </div>
            <div className="bg-gray-800 rounded-xl p-3">
              <div className="text-gray-500 text-xs">Currency</div>
              <div className="text-white font-semibold text-sm mt-0.5">USD 🇺🇸</div>
            </div>
          </div>
        </div>
      </div>

      {/* Trading Stats */}
      <div>
        <h3 className="text-white font-semibold mb-3">Trading Statistics</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {stats.map(s => (
            <div key={s.label} className="bg-gray-900 border border-gray-800 rounded-2xl p-4 flex flex-col gap-1">
              <span className="text-2xl">{s.icon}</span>
              <div className={`text-xl font-bold ${s.color}`}>{s.value}</div>
              <div className="text-gray-500 text-xs">{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Progress to Next Level */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-white font-semibold">Account Progress</h3>
          <span className="text-amber-400 text-sm font-semibold">⭐ Gold → 💎 Platinum</span>
        </div>
        <div className="mb-2">
          <div className="flex justify-between text-xs text-gray-400 mb-1.5">
            <span>Trading Volume Progress</span>
            <span className="text-white font-semibold">$8,420 / $25,000</span>
          </div>
          <div className="bg-gray-800 rounded-full h-3 overflow-hidden">
            <div className="h-3 rounded-full bg-gradient-to-r from-amber-400 to-amber-500" style={{ width: "33.7%" }}></div>
          </div>
        </div>
        <p className="text-gray-500 text-xs mt-2">Reach $25,000 trading volume to unlock Platinum tier benefits: higher payouts, priority withdrawals, and a dedicated account manager.</p>
      </div>

      {/* Edit Profile */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <h3 className="text-white font-semibold mb-4">Edit Profile</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {[
            { label: "First Name", value: "John", type: "text" },
            { label: "Last Name", value: "Doe", type: "text" },
            { label: "Email", value: "john.doe@email.com", type: "email" },
            { label: "Phone", value: "+1 555-0123", type: "tel" },
          ].map(f => (
            <div key={f.label}>
              <label className="text-gray-400 text-xs font-medium block mb-1.5">{f.label}</label>
              <input
                type={f.type}
                defaultValue={f.value}
                className="w-full bg-gray-800 border border-gray-700 focus:border-emerald-500 text-white rounded-xl px-4 py-2.5 text-sm outline-none transition-colors"
              />
            </div>
          ))}
        </div>
        <div className="mt-4">
          <label className="text-gray-400 text-xs font-medium block mb-1.5">Address</label>
          <input
            type="text"
            defaultValue="123 Main St, New York, NY 10001"
            className="w-full bg-gray-800 border border-gray-700 focus:border-emerald-500 text-white rounded-xl px-4 py-2.5 text-sm outline-none transition-colors"
          />
        </div>
        <button className="mt-4 bg-emerald-500 hover:bg-emerald-400 text-white font-semibold px-6 py-2.5 rounded-xl text-sm transition-colors">
          Save Changes
        </button>
      </div>

      {/* KYC Status */}
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <h3 className="text-white font-semibold mb-3">Identity Verification (KYC)</h3>
        <div className="flex items-start gap-4 p-4 bg-emerald-500/5 border border-emerald-500/20 rounded-xl">
          <div className="w-10 h-10 rounded-full bg-emerald-500/20 flex items-center justify-center flex-shrink-0">
            <svg className="w-5 h-5 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div>
            <div className="text-emerald-400 font-semibold">KYC Verified</div>
            <div className="text-gray-400 text-sm mt-0.5">Your identity has been verified. You have full access to all platform features including deposits, withdrawals, and trading.</div>
            <div className="text-gray-600 text-xs mt-2">Verified on: February 15, 2024</div>
          </div>
        </div>
        <div className="mt-3 grid grid-cols-3 gap-2">
          {[
            { label: "Passport", status: "verified" },
            { label: "Selfie", status: "verified" },
            { label: "Proof of Address", status: "verified" },
          ].map(d => (
            <div key={d.label} className={cn("text-center py-2.5 px-2 rounded-xl border text-xs font-semibold",
              "bg-emerald-500/5 border-emerald-500/20 text-emerald-400"
            )}>
              ✅ {d.label}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
