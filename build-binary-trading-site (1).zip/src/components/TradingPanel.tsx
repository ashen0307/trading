import { useState } from "react";
import { cn } from "@/utils/cn";

interface TradingPanelProps {
  onTrade: (direction: "up" | "down", amount: number, duration: number) => void;
  isTrading: boolean;
  direction: "up" | "down" | null;
  timeLeft: number;
  balance: number;
  lastResult: { won: boolean; profit: number } | null;
  payout: number;
}

const AMOUNTS = [5, 10, 25, 50, 100, 250];
const DURATIONS = [
  { label: "30s", value: 30 },
  { label: "1m", value: 60 },
  { label: "2m", value: 120 },
  { label: "5m", value: 300 },
];

export function TradingPanel({ onTrade, isTrading, direction, timeLeft, balance, lastResult, payout }: TradingPanelProps) {
  const [amount, setAmount] = useState(25);
  const [customAmount, setCustomAmount] = useState("");
  const [duration, setDuration] = useState(60);

  const activeAmount = customAmount ? parseFloat(customAmount) : amount;
  const potentialProfit = activeAmount * (payout / 100);

  const handleTrade = (dir: "up" | "down") => {
    const a = customAmount ? parseFloat(customAmount) : amount;
    if (!a || a <= 0 || a > balance) return;
    onTrade(dir, a, duration);
  };

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5 flex flex-col gap-5">
      <h2 className="text-white font-semibold text-lg flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse inline-block"></span>
        Place Trade
      </h2>

      {/* Last Result Banner */}
      {lastResult && !isTrading && (
        <div className={cn(
          "rounded-xl px-4 py-3 flex items-center justify-between text-sm font-semibold",
          lastResult.won ? "bg-emerald-500/20 border border-emerald-500/30 text-emerald-400" : "bg-red-500/20 border border-red-500/30 text-red-400"
        )}>
          <span>{lastResult.won ? "🎉 Trade Won!" : "❌ Trade Lost"}</span>
          <span>{lastResult.won ? `+$${lastResult.profit.toFixed(2)}` : `-$${lastResult.profit.toFixed(2)}`}</span>
        </div>
      )}

      {/* Duration */}
      <div>
        <label className="text-gray-400 text-xs font-medium uppercase tracking-wider mb-2 block">Expiry Time</label>
        <div className="grid grid-cols-4 gap-2">
          {DURATIONS.map(d => (
            <button
              key={d.value}
              onClick={() => setDuration(d.value)}
              disabled={isTrading}
              className={cn(
                "py-2 rounded-lg text-sm font-semibold transition-all",
                duration === d.value
                  ? "bg-cyan-500 text-white shadow-lg shadow-cyan-500/25"
                  : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white",
                isTrading && "opacity-50 cursor-not-allowed"
              )}
            >
              {d.label}
            </button>
          ))}
        </div>
      </div>

      {/* Amount */}
      <div>
        <label className="text-gray-400 text-xs font-medium uppercase tracking-wider mb-2 block">Investment Amount</label>
        <div className="grid grid-cols-3 gap-2 mb-3">
          {AMOUNTS.map(a => (
            <button
              key={a}
              onClick={() => { setAmount(a); setCustomAmount(""); }}
              disabled={isTrading}
              className={cn(
                "py-2 rounded-lg text-sm font-semibold transition-all",
                amount === a && !customAmount
                  ? "bg-violet-600 text-white shadow-lg shadow-violet-500/25"
                  : "bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white",
                isTrading && "opacity-50 cursor-not-allowed"
              )}
            >
              ${a}
            </button>
          ))}
        </div>
        <div className="relative">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 font-semibold">$</span>
          <input
            type="number"
            value={customAmount}
            onChange={e => setCustomAmount(e.target.value)}
            placeholder="Custom amount"
            disabled={isTrading}
            className="w-full bg-gray-800 border border-gray-700 focus:border-violet-500 text-white rounded-lg pl-7 pr-4 py-2.5 text-sm outline-none transition-colors disabled:opacity-50"
          />
        </div>
      </div>

      {/* Payout Info */}
      <div className="bg-gray-800 rounded-xl px-4 py-3 flex items-center justify-between text-sm">
        <span className="text-gray-400">Potential Payout</span>
        <div className="text-right">
          <span className="text-emerald-400 font-bold text-base">+${potentialProfit.toFixed(2)}</span>
          <span className="text-gray-500 ml-1">({payout}%)</span>
        </div>
      </div>

      {/* Trade Buttons */}
      {isTrading ? (
        <div className={cn(
          "rounded-xl p-4 text-center",
          direction === "up" ? "bg-emerald-500/10 border border-emerald-500/30" : "bg-red-500/10 border border-red-500/30"
        )}>
          <div className={cn("text-lg font-bold mb-1", direction === "up" ? "text-emerald-400" : "text-red-400")}>
            {direction === "up" ? "▲ CALL Trade Active" : "▼ PUT Trade Active"}
          </div>
          <div className="text-gray-400 text-sm">Expires in <span className="text-white font-semibold">{timeLeft}s</span></div>
          <div className="mt-3 w-full bg-gray-800 rounded-full h-2 overflow-hidden">
            <div
              className={cn("h-2 rounded-full transition-all", direction === "up" ? "bg-emerald-500" : "bg-red-500")}
              style={{ width: `${(timeLeft / duration) * 100}%` }}
            />
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => handleTrade("up")}
            className="flex flex-col items-center gap-1 py-4 bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-white rounded-xl font-bold text-base transition-all shadow-lg shadow-emerald-500/25"
          >
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 15l7-7 7 7" />
            </svg>
            CALL
          </button>
          <button
            onClick={() => handleTrade("down")}
            className="flex flex-col items-center gap-1 py-4 bg-red-500 hover:bg-red-400 active:scale-95 text-white rounded-xl font-bold text-base transition-all shadow-lg shadow-red-500/25"
          >
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
            </svg>
            PUT
          </button>
        </div>
      )}

      <p className="text-gray-600 text-xs text-center">
        Trading involves risk. Only invest what you can afford to lose.
      </p>
    </div>
  );
}
