import { cn } from "@/utils/cn";

export interface Asset {
  id: string;
  name: string;
  symbol: string;
  price: number;
  change: number;
  icon: string;
  payout: number;
}

interface AssetSelectorProps {
  assets: Asset[];
  selectedId: string;
  onSelect: (id: string) => void;
}

export function AssetSelector({ assets, selectedId, onSelect }: AssetSelectorProps) {
  return (
    <div className="bg-gray-900 border border-gray-800 rounded-2xl p-4">
      <h3 className="text-gray-400 text-xs font-medium uppercase tracking-wider mb-3">Markets</h3>
      <div className="flex flex-col gap-1">
        {assets.map(asset => (
          <button
            key={asset.id}
            onClick={() => onSelect(asset.id)}
            className={cn(
              "w-full flex items-center justify-between px-3 py-2.5 rounded-xl transition-all text-left",
              selectedId === asset.id
                ? "bg-gray-800 border border-gray-700"
                : "hover:bg-gray-800/60 border border-transparent"
            )}
          >
            <div className="flex items-center gap-2.5">
              <span className="text-xl">{asset.icon}</span>
              <div>
                <div className="text-white text-sm font-semibold">{asset.symbol}</div>
                <div className="text-gray-500 text-xs">{asset.name}</div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-white text-sm font-mono font-semibold">{asset.price.toFixed(2)}</div>
              <div className={cn("text-xs font-medium", asset.change >= 0 ? "text-emerald-400" : "text-red-400")}>
                {asset.change >= 0 ? "+" : ""}{asset.change.toFixed(2)}%
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
