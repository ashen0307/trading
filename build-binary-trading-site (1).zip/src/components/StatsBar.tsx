interface StatsBarProps {
  currentPrice: number;
  open: number;
  high: number;
  low: number;
  volume: string;
  payout: number;
  assetName: string;
}

export function StatsBar({ currentPrice, open, high, low, volume, payout, assetName }: StatsBarProps) {
  const change = currentPrice - open;
  const changePct = (change / open) * 100;
  const isUp = change >= 0;

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-2xl px-5 py-3 flex flex-wrap items-center gap-4 md:gap-8">
      <div>
        <div className="text-gray-500 text-xs mb-0.5">{assetName}</div>
        <div className="text-white text-2xl font-bold font-mono">{currentPrice.toFixed(2)}</div>
        <div className={`text-sm font-semibold ${isUp ? "text-emerald-400" : "text-red-400"}`}>
          {isUp ? "+" : ""}{change.toFixed(2)} ({isUp ? "+" : ""}{changePct.toFixed(2)}%)
        </div>
      </div>
      <div className="h-10 w-px bg-gray-800 hidden md:block"></div>
      {[
        { label: "Open", value: open.toFixed(2) },
        { label: "High", value: high.toFixed(2) },
        { label: "Low", value: low.toFixed(2) },
        { label: "Volume", value: volume },
        { label: "Payout", value: `${payout}%` },
      ].map(stat => (
        <div key={stat.label}>
          <div className="text-gray-500 text-xs mb-0.5">{stat.label}</div>
          <div className="text-white text-sm font-semibold font-mono">{stat.value}</div>
        </div>
      ))}
    </div>
  );
}
