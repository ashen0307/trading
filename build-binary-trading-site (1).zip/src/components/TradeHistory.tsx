import { cn } from "@/utils/cn";

export interface TradeRecord {
  id: string;
  asset: string;
  direction: "up" | "down";
  amount: number;
  profit: number;
  won: boolean;
  entryPrice: number;
  exitPrice: number;
  time: string;
}

interface TradeHistoryProps {
  trades: TradeRecord[];
}

export function TradeHistory({ trades }: TradeHistoryProps) {
  if (trades.length === 0) {
    return (
      <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
        <h3 className="text-white font-semibold mb-4">Trade History</h3>
        <div className="text-center py-8 text-gray-600">
          <svg className="w-10 h-10 mx-auto mb-2 opacity-50" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
          </svg>
          <p className="text-sm">No trades yet</p>
        </div>
      </div>
    );
  }

  const totalProfit = trades.reduce((sum, t) => sum + (t.won ? t.profit : -t.amount), 0);
  const winRate = Math.round((trades.filter(t => t.won).length / trades.length) * 100);

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-2xl p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-white font-semibold">Trade History</h3>
        <div className="flex items-center gap-3 text-xs">
          <span className="text-gray-400">Win Rate: <span className={cn("font-bold", winRate >= 50 ? "text-emerald-400" : "text-red-400")}>{winRate}%</span></span>
          <span className={cn("font-bold text-sm", totalProfit >= 0 ? "text-emerald-400" : "text-red-400")}>
            {totalProfit >= 0 ? "+" : ""}${totalProfit.toFixed(2)}
          </span>
        </div>
      </div>

      <div className="flex flex-col gap-2 max-h-72 overflow-y-auto pr-1 custom-scroll">
        {[...trades].reverse().map(trade => (
          <div
            key={trade.id}
            className={cn(
              "flex items-center justify-between px-3 py-2.5 rounded-xl border text-sm",
              trade.won
                ? "bg-emerald-500/5 border-emerald-500/20"
                : "bg-red-500/5 border-red-500/20"
            )}
          >
            <div className="flex items-center gap-2.5">
              <div className={cn(
                "w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold",
                trade.direction === "up" ? "bg-emerald-500" : "bg-red-500"
              )}>
                {trade.direction === "up" ? "▲" : "▼"}
              </div>
              <div>
                <div className="text-white font-medium">{trade.asset}</div>
                <div className="text-gray-500 text-xs">{trade.time}</div>
              </div>
            </div>
            <div className="text-center hidden sm:block">
              <div className="text-gray-400 text-xs">Entry / Exit</div>
              <div className="text-white font-mono text-xs">{trade.entryPrice.toFixed(2)} → {trade.exitPrice.toFixed(2)}</div>
            </div>
            <div className="text-right">
              <div className={cn("font-bold", trade.won ? "text-emerald-400" : "text-red-400")}>
                {trade.won ? `+$${trade.profit.toFixed(2)}` : `-$${trade.amount.toFixed(2)}`}
              </div>
              <div className="text-gray-500 text-xs">${trade.amount} invested</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
